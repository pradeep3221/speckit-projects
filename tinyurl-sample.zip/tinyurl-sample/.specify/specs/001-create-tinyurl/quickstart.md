# Quickstart: snip.ly URL Shortener

## Prerequisites
- **Node.js** >= 20.0.0
- **npm** >= 9

## Setup

```bash
# Clone and install
git clone <repo-url>
cd tinyurl-sample
npm install
```

## Run

```bash
# Development (with pretty logging)
npm start
# → Server starts at http://localhost:3000

# Custom port
PORT=8080 npm start
```

## Verify

```bash
# Health check
curl http://localhost:3000/health

# Create a short URL
curl -X POST http://localhost:3000/api/v1/urls \
  -H "Content-Type: application/json" \
  -d '{"url": "https://example.com/hello-world"}'

# Create with custom alias
curl -X POST http://localhost:3000/api/v1/urls \
  -H "Content-Type: application/json" \
  -d '{"url": "https://example.com/hello-world", "customCode": "hello"}'

# Redirect (follow redirects)
curl -L http://localhost:3000/hello

# View analytics
curl http://localhost:3000/api/v1/urls/hello/stats

# List all URLs
curl "http://localhost:3000/api/v1/urls?page=1&limit=10"

# Delete (soft-delete)
curl -X DELETE http://localhost:3000/api/v1/urls/hello
```

## Frontend

Open `http://localhost:3000` in a browser to access the SPA with:
- **Shorten** tab: Paste URL, optionally set custom alias, click "SHORTEN →"
- **My Links** tab: Browse, search, delete, view analytics for all links
- **API Docs** tab: Full REST API reference

## Test

```bash
# Run all tests
npm test

# Run with coverage
npm run test:coverage

# Run specific test file
npx vitest run tests/unit/url-service.test.js
```

## Docker

```bash
# Build
docker build -t snip-ly .

# Run
docker run -p 3000:3000 -v snip-data:/app/data snip-ly

# Health check
curl http://localhost:3000/health
```

## Configuration

| Environment Variable | Default | Description |
|---------------------|---------|-------------|
| `PORT` | `3000` | Server port |
| `BASE_URL` | `http://localhost:3000` | Base URL for generated short links |
| `DB_PATH` | `./data/urls.db` | SQLite database file path |
| `LOG_LEVEL` | `info` | Pino log level (trace/debug/info/warn/error) |
| `SHORT_CODE_LENGTH` | `6` | Length of auto-generated short codes |
| `NODE_ENV` | `development` | Environment (development/production) |
