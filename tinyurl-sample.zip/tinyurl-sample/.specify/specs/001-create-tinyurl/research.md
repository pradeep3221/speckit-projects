# Research Notes: snip.ly — Production-Ready URL Shortener

**Date**: 2026-03-22  
**Feature**: 001-create-tinyurl  
**Status**: All NEEDS CLARIFICATION resolved

## Technology Research

### Node.js 20 LTS
- **Decision**: Node.js 20 LTS
- **Rationale**: Long-term support until April 2026; native ES module support via `"type": "module"`. Built-in URL constructor for validation, crypto for UUIDs.
- **Alternatives considered**: Node 22 (current, but LTS preferred for stability), Deno (smaller ecosystem)

### Express 4.x
- **Decision**: Express 4.21
- **Rationale**: Most popular Node.js web framework, mature and stable. Express 5 still in beta.
- **Alternatives considered**: Fastify (faster but Express is simpler per Constitution I), Koa (smaller ecosystem)

### SQLite via sql.js
- **Decision**: sql.js (WebAssembly-based SQLite)
- **Rationale**: Zero external dependencies, in-memory with file persistence, no native compilation needed (unlike better-sqlite3). WAL mode for concurrent reads. The codebase uses sql.js rather than better-sqlite3.
- **Alternatives considered**: better-sqlite3 (faster native bindings but requires compilation), PostgreSQL (overkill for single-server demo)
- **Trade-off**: sql.js is async via WASM; slightly slower than better-sqlite3's synchronous C++ bindings, but compilation-free portability wins for a demo/portfolio project.

### nanoid (Custom Base62 Alphabet)
- **Decision**: nanoid 5 with custom alphabet `0-9A-Za-z`
- **Rationale**: Cryptographically random, configurable length, URL-safe. Meets "unpredictable codes" security requirement.
- **Key metric**: 6 chars with 62-char alphabet = 62⁶ ≈ 56.8 billion unique IDs. At 1,000 IDs/hour: ~1 collision per 1 billion years.
- **Alternatives considered**: UUID (too long), hashids (reversible/predictable), sequential IDs (violates Constitution IV)

### express-rate-limit
- **Decision**: express-rate-limit 7 (in-memory store)
- **Rationale**: Simple, no Redis dependency, standard `429 Too Many Requests` with `Retry-After` header.
- **Limitation**: Resets on restart; per-instance only. Acceptable for single-server scope.
- **Alternatives considered**: rate-limiter-flexible (more features but more complex), Redis-backed (violates zero-dependency constraint)

### Pino Structured Logging
- **Decision**: pino 9 + pino-http 10
- **Rationale**: Fastest JSON logger for Node.js, native request correlation, configurable redaction paths.
- **Configuration**: Redacts `authorization`, `cookie` headers. Pretty-print in development via pino-pretty.
- **Alternatives considered**: winston (slower), bunyan (less maintained)

### Helmet Security Headers
- **Decision**: helmet 8
- **Rationale**: Sets X-Content-Type-Options, X-Frame-Options, CSP, HSTS, referrer policy.
- **Alternatives considered**: Manual header setting (error-prone)

### Vitest + Supertest
- **Decision**: vitest 3 + supertest 7 + @vitest/coverage-v8
- **Rationale**: Fast ESM-native test runner, Jest-compatible API, built-in coverage. Supertest for HTTP integration.
- **Coverage target**: 80% (statements, branches, functions, lines) per Constitution III and SC-007.

## Resolved Unknowns

### RU-001: Short Code Length — 6 vs 7
- **Context**: Spec requires 6-char Base62; existing implementation defaults to 7.
- **Decision**: Change to **6 characters** per spec.
- **Rationale**: 62⁶ ≈ 56.8 billion unique codes is sufficient. The spec explicitly states "6-char Base62" in FR-001, US-1, and SC-006. All test assertions using length 7 must be updated.
- **Impact**: `config.js` (shortCodeLength: 6), `code-generator.js`, all test assertions checking code length.

### RU-002: Redirect Rate Limiter Not Wired
- **Context**: `redirectLimiter` (1000/min per IP) is defined in `rate-limiter.js` but never applied to redirect route in `app.js`.
- **Decision**: Wire `redirectLimiter` to the redirect route.
- **Rationale**: FR-006 requires rate-limiting redirects at 1,000 requests/min per IP. Without it, the redirect endpoint is unprotected.
- **Impact**: `app.js` — add `redirectLimiter` middleware to the redirect route mount.

### RU-003: Dockerfile Missing public/ Directory
- **Context**: Docker production stage copies `src/` but not `public/`, so the SPA frontend won't be served from Docker.
- **Decision**: Add `COPY --from=builder /app/public ./public` to Dockerfile.
- **Rationale**: FR-012 requires serving the SPA frontend. Without the public directory, Docker deployments serve only the API.
- **Impact**: `Dockerfile` — one additional COPY line.

### RU-004: Custom Code Character Set (Underscore)
- **Context**: Validator regex allows `[a-zA-Z0-9-]` (no underscore). Swagger doc says `[a-zA-Z0-9_-]`.
- **Decision**: Keep **without underscores** — `[a-zA-Z0-9-]` only.
- **Rationale**: Spec says "alphanumeric with hyphens only" (User Story 4, FR-007). The swagger doc should be corrected to match the spec.
- **Impact**: Fix swagger.js to document `[a-zA-Z0-9-]` pattern. No validator change needed.

### RU-005: Link Ownership Model
- **Context**: "My Links" tab implies per-user scoping, but no auth exists.
- **Decision**: Public/shared — no authentication. "My Links" shows all links globally.
- **Rationale**: Clarified in session. Keeps scope minimal for demo/portfolio project.
- **Impact**: No user_id column needed. API returns all URLs regardless of origin.

### RU-006: Database Persistence
- **Context**: Spec doesn't declare whether data must survive restarts.
- **Decision**: SQLite file-based persistence (data directory at `./data/urls.db`).
- **Rationale**: Clarified in session. WAL mode for concurrent reads sufficient for SC-003 target.
- **Impact**: Already implemented in `database.js` with `saveDatabase()` on shutdown.

### RU-007: Delete Confirmation UX
- **Context**: Spec says "confirms the dialog" without specifying which pattern.
- **Decision**: Browser native `confirm()` dialog.
- **Rationale**: Clarified in session. Simplest implementation; acceptable for demo scope.
- **Impact**: Frontend uses `window.confirm()` before DELETE call.

### RU-008: Default Sort Order
- **Context**: Spec doesn't define sort order for link list.
- **Decision**: Newest first (descending by `created_at`).
- **Rationale**: Most intuitive default. Already implemented in data model query.
- **Impact**: None — already matches implementation.

### RU-009: Custom Alias Length Asymmetry
- **Context**: Frontend allows 3–20 chars; API allows 3–30 chars.
- **Decision**: Keep asymmetry (confirmed in session).
- **Rationale**: Progressive disclosure — tighter UI constraints for simplicity, wider API for power users.
- **Impact**: Frontend validates 3–20 client-side; validator.js validates 3–30 server-side. Both already implemented correctly.

## URL Validation Approach
- Use `new URL()` constructor (built-in) for format validation.
- Restrict schemes to `http` and `https` only (reject `ftp`, `file`, `javascript`, etc.).
- Maximum URL length: 10,000 characters (FR-003).
- No DNS resolution check — validates format only (avoids latency and false negatives).
- Already implemented in `validator.js`.

## Redirect Strategy
- HTTP 301 (Moved Permanently) — standard for URL shorteners.
- `Cache-Control: public, max-age=86400` on redirects for CDN edge caching (FR-002).
- Deactivated URLs return HTTP 410 Gone (FR-011).
- Analytics recording is synchronous but failure-tolerant (FR-004 graceful degradation).
- Already implemented in `redirect.js`.

## Frontend Architecture
- Single-page application served as static `public/index.html`.
- No build step, no framework dependency — vanilla HTML/CSS/JS.
- Dark terminal aesthetic: JetBrains Mono font, CRT scanline overlay, `#00ff9f` green accent.
- Tabs: Shorten (default), My Links (with search/pagination/delete), API Docs.
- Analytics modal: animated counter, 14-day SVG sparkline, geo/browser/device tabs, SVG QR code.
- Mock geo/browser/device data from deterministic hash of short code (per Assumptions).
- 900ms simulated delay on URL creation (frontend-only, per Assumptions).
- Already fully implemented in `public/index.html`.

## Security Considerations
- **helmet**: Sets security headers automatically.
- **Rate limiting**: 100/min per IP for creation, 1000/min per IP for redirects (FR-006). Creation limiter is wired; redirect limiter needs wiring (RU-002).
- **Input validation**: URL format + scheme + length checked server-side.
- **No open redirects**: Short codes must exist in database; no pass-through.
- **Unpredictable codes**: nanoid is cryptographically random; no sequential guessing.
- **No auth needed**: Public instance (RU-005); no sensitive data to protect per-user.
