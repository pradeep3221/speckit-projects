import { useState, useEffect, useCallback, useRef } from "react";

// ── Utility helpers ────────────────────────────────────────────────
const BASE = "https://snip.ly/";
const CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
const uid = (n = 6) => Array.from({ length: n }, () => CHARS[Math.floor(Math.random() * CHARS.length)]).join("");
const now = () => new Date().toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });
const fmtNum = (n) => n >= 1_000_000 ? (n / 1_000_000).toFixed(1) + "M" : n >= 1000 ? (n / 1000).toFixed(1) + "K" : String(n);
const getDomain = (url) => { try { return new URL(url).hostname; } catch { return url; } };
const isValid = (url) => { try { new URL(url); return true; } catch { return false; } };
const COUNTRIES = ["IN","US","GB","DE","JP","BR","CA","FR","AU","SG"];
const BROWSERS  = ["Chrome","Safari","Firefox","Edge","Opera"];
const DEVICES   = ["Mobile","Desktop","Tablet"];

function randomStats() {
  const clicks = Math.floor(Math.random() * 9800 + 200);
  const geo = COUNTRIES.map(c => ({ country: c, pct: 0 }));
  let rem = 100;
  geo.forEach((g, i) => {
    const v = i === geo.length - 1 ? rem : Math.floor(Math.random() * (rem / (geo.length - i)));
    g.pct = v; rem -= v;
  });
  return {
    clicks,
    geo: geo.sort((a, b) => b.pct - a.pct).slice(0, 5),
    browsers: BROWSERS.map(b => ({ name: b, pct: Math.floor(Math.random() * 40 + 5) })),
    devices: DEVICES.map(d => ({ name: d, pct: 0 })).map((d, i) => ({ ...d, pct: [52, 38, 10][i] })),
    trend: Array.from({ length: 14 }, (_, i) => ({ day: i + 1, clicks: Math.floor(Math.random() * (clicks / 8) + 10) })),
  };
}

// ── QR SVG generator ─────────────────────────────────────
function QRPlaceholder({ value, size = 120 }) {
  const seed = value.split("").reduce((a, c) => a + c.charCodeAt(0), 0);
  const rng = (i) => ((seed * (i + 37)) % 97) / 97;
  const GRID = 21;
  const cells = Array.from({ length: GRID * GRID }, (_, i) => {
    const r = Math.floor(i / GRID), c = i % GRID;
    if ((r < 7 && c < 7) || (r < 7 && c >= GRID - 7) || (r >= GRID - 7 && c < 7)) return 1;
    return rng(i) > 0.5 ? 1 : 0;
  });
  const cs = size / GRID;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <rect width={size} height={size} fill="white" rx="4" />
      {cells.map((v, i) => v ? (
        <rect key={i} x={Math.floor(i % GRID) * cs} y={Math.floor(i / GRID) * cs} width={cs} height={cs} fill="#0a0a0a" />
      ) : null)}
    </svg>
  );
}

// ── Sparkline ─────────────────────────────────────────────
function Sparkline({ data, color = "#00f5a0", width = 200, height = 40 }) {
  const max = Math.max(...data.map(d => d.clicks), 1);
  const pts = data.map((d, i) => {
    const x = (i / (data.length - 1)) * width;
    const y = height - (d.clicks / max) * height;
    return `${x},${y}`;
  }).join(" ");
  const area = `0,${height} ${pts} ${width},${height}`;
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
      <defs>
        <linearGradient id="sg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polyline points={area} fill="url(#sg)" />
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinejoin="round" />
    </svg>
  );
}

// ── Bar chart ─────────────────────────────────────────────
function HBar({ label, pct, color = "#00f5a0" }) {
  return (
    <div style={{ marginBottom: 8 }}>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#888", marginBottom: 3 }}>
        <span>{label}</span><span style={{ color: "#ccc" }}>{pct}%</span>
      </div>
      <div style={{ height: 5, borderRadius: 99, background: "#1c1c1c", overflow: "hidden" }}>
        <div style={{ width: `${pct}%`, height: "100%", borderRadius: 99, background: color, transition: "width 1s ease" }} />
      </div>
    </div>
  );
}

// ── Toast ──────────────────────────────────────────────────
function Toast({ msg, onDone }) {
  useEffect(() => { const t = setTimeout(onDone, 2200); return () => clearTimeout(t); }, []);
  return (
    <div style={{
      position: "fixed", bottom: 28, right: 28, zIndex: 999,
      background: "#00f5a0", color: "#0a0a0a", padding: "10px 18px",
      borderRadius: 8, fontSize: 13, fontWeight: 700,
      fontFamily: "'DM Mono', monospace",
      boxShadow: "0 0 24px #00f5a066",
      animation: "slideUp .3s ease"
    }}>{msg}</div>
  );
}

// ── Link Card ──────────────────────────────────────────────
function LinkCard({ link, onOpen, onCopy, onDelete }) {
  return (
    <div style={{
      background: "#111", border: "1px solid #1e1e1e", borderRadius: 12,
      padding: "16px 18px", display: "flex", alignItems: "center", gap: 14,
      transition: "border-color .2s", animation: "fadeIn .4s ease"
    }}
      onMouseEnter={e => e.currentTarget.style.borderColor = "#2a2a2a"}
      onMouseLeave={e => e.currentTarget.style.borderColor = "#1e1e1e"}
    >
      <div style={{
        width: 38, height: 38, borderRadius: 8, background: "#1a1a1a",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 16, flexShrink: 0
      }}>{link.emoji}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 2 }}>
          <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 13, color: "#00f5a0", fontWeight: 600 }}>
            {BASE}{link.slug}
          </span>
          {link.custom && <span style={{ fontSize: 9, background: "#1a3a2a", color: "#00f5a0", padding: "1px 5px", borderRadius: 4 }}>CUSTOM</span>}
        </div>
        <div style={{ fontSize: 11, color: "#555", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 280 }}>
          {link.url}
        </div>
        <div style={{ display: "flex", gap: 12, marginTop: 4, fontSize: 10, color: "#444" }}>
          <span>📅 {link.createdAt}</span>
          <span>👁 {fmtNum(link.stats.clicks)} clicks</span>
          <span>🌍 {link.stats.geo[0]?.country}</span>
        </div>
      </div>
      <div style={{ display: "flex", gap: 6 }}>
        <ActionBtn icon="📊" label="Analytics" onClick={() => onOpen(link)} />
        <ActionBtn icon="📋" label="Copy" onClick={() => onCopy(link)} />
        <ActionBtn icon="🗑" label="Delete" onClick={() => onDelete(link.id)} danger />
      </div>
    </div>
  );
}

function ActionBtn({ icon, label, onClick, danger }) {
  const [hov, setHov] = useState(false);
  return (
    <button onClick={onClick}
      onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      title={label}
      style={{
        background: hov ? (danger ? "#2a1010" : "#1a2a1a") : "#161616",
        border: `1px solid ${hov ? (danger ? "#662222" : "#2a3a2a") : "#1e1e1e"}`,
        borderRadius: 7, width: 32, height: 32, cursor: "pointer",
        fontSize: 14, display: "flex", alignItems: "center", justifyContent: "center",
        transition: "all .15s"
      }}>{icon}</button>
  );
}

// ── Analytics Modal ────────────────────────────────────────
function AnalyticsModal({ link, onClose }) {
  const [tab, setTab] = useState("geo");
  const tabs = ["geo", "browser", "device"];
  const tabData = {
    geo: link.stats.geo.map(g => ({ label: g.country, pct: g.pct })),
    browser: link.stats.browsers.map(b => ({ label: b.name, pct: b.pct })),
    device: link.stats.devices.map(d => ({ label: d.name, pct: d.pct })),
  };
  return (
    <div style={{
      position: "fixed", inset: 0, background: "#000000cc", zIndex: 100,
      display: "flex", alignItems: "center", justifyContent: "center",
      backdropFilter: "blur(4px)"
    }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{
        background: "#0d0d0d", border: "1px solid #222", borderRadius: 16,
        width: 560, maxHeight: "85vh", overflow: "auto",
        boxShadow: "0 0 60px #00000088",
        animation: "scaleIn .25s ease"
      }}>
        <div style={{ padding: "20px 24px", borderBottom: "1px solid #1a1a1a", display: "flex", justifyContent: "space-between", alignItems: "start" }}>
          <div>
            <div style={{ fontFamily: "'DM Mono', monospace", color: "#00f5a0", fontWeight: 700, fontSize: 15 }}>
              {BASE}{link.slug}
            </div>
            <div style={{ fontSize: 11, color: "#555", marginTop: 2 }}>{getDomain(link.url)}</div>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", color: "#555", cursor: "pointer", fontSize: 18 }}>✕</button>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 1, background: "#1a1a1a" }}>
          {[
            { label: "Total Clicks", val: fmtNum(link.stats.clicks), icon: "👆" },
            { label: "Top Country", val: link.stats.geo[0]?.country, icon: "🌍" },
            { label: "Created", val: link.createdAt, icon: "📅" },
          ].map(s => (
            <div key={s.label} style={{ background: "#0d0d0d", padding: "16px 20px" }}>
              <div style={{ fontSize: 10, color: "#555", marginBottom: 4 }}>{s.icon} {s.label}</div>
              <div style={{ fontSize: 18, fontWeight: 700, color: "#eee", fontFamily: "'DM Mono', monospace" }}>{s.val}</div>
            </div>
          ))}
        </div>

        <div style={{ padding: "20px 24px", borderBottom: "1px solid #1a1a1a" }}>
          <div style={{ fontSize: 10, color: "#555", marginBottom: 10, letterSpacing: 1 }}>LAST 14 DAYS</div>
          <Sparkline data={link.stats.trend} width={510} height={60} />
        </div>

        <div style={{ padding: "20px 24px" }}>
          <div style={{ display: "flex", gap: 6, marginBottom: 16 }}>
            {tabs.map(t => (
              <button key={t} onClick={() => setTab(t)} style={{
                background: tab === t ? "#00f5a0" : "#161616",
                color: tab === t ? "#0a0a0a" : "#555",
                border: "none", borderRadius: 6, padding: "5px 12px",
                fontSize: 11, fontWeight: 700, cursor: "pointer",
                fontFamily: "inherit", letterSpacing: .5,
                transition: "all .15s", textTransform: "uppercase"
              }}>{t}</button>
            ))}
          </div>
          {tabData[tab].map(d => <HBar key={d.label} label={d.label} pct={d.pct} />)}
        </div>

        <div style={{ padding: "0 24px 24px", display: "flex", gap: 16, alignItems: "center" }}>
          <QRPlaceholder value={link.slug} size={80} />
          <div style={{ fontSize: 11, color: "#444", lineHeight: 1.6 }}>
            QR code for<br />
            <span style={{ color: "#00f5a0", fontFamily: "'DM Mono', monospace" }}>{BASE}{link.slug}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Seed Data ──────────────────────────────────────────────
const EMOJIS = ["🔗","🚀","⚡","🌐","📎","🎯","💡","🔥","✨","🎪"];
const SEED_LINKS = [
  { url: "https://github.com/openai/gpt-4", slug: "gpt4gh", custom: false },
  { url: "https://vercel.com/blog/next-15", slug: "next15", custom: true },
  { url: "https://tailwindcss.com/docs", slug: "twdocs", custom: true },
].map((l, i) => ({
  ...l, id: i + 1,
  emoji: EMOJIS[i % EMOJIS.length],
  createdAt: now(), stats: randomStats(),
}));

// ── Main App ───────────────────────────────────────────────
export default function App() {
  const [links, setLinks] = useState(SEED_LINKS);
  const [url, setUrl] = useState("");
  const [alias, setAlias] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState(null);
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState("");
  const [view, setView] = useState("home");
  const inputRef = useRef(null);

  const totalClicks = links.reduce((a, l) => a + l.stats.clicks, 0);

  const shorten = useCallback(async () => {
    setError("");
    if (!url.trim()) { setError("Please enter a URL"); return; }
    if (!isValid(url.trim())) { setError("Invalid URL — include https://"); return; }
    if (alias && !/^[a-zA-Z0-9_-]{3,20}$/.test(alias)) {
      setError("Alias must be 3–20 chars: letters, numbers, _ or -"); return;
    }
    if (alias && links.find(l => l.slug === alias)) {
      setError("That alias is already taken"); return;
    }
    setLoading(true);
    await new Promise(r => setTimeout(r, 900));
    const slug = alias || uid();
    const link = { id: Date.now(), url: url.trim(), slug, custom: !!alias, emoji: EMOJIS[Math.floor(Math.random() * EMOJIS.length)], createdAt: now(), stats: randomStats() };
    setLinks(prev => [link, ...prev]);
    setUrl(""); setAlias("");
    setLoading(false);
    setToast(`✓ Created: ${BASE}${slug}`);
    setView("links");
  }, [url, alias, links]);

  const copyLink = useCallback((link) => {
    navigator.clipboard?.writeText(BASE + link.slug);
    setToast(`Copied ${BASE}${link.slug}`);
  }, []);

  const deleteLink = useCallback((id) => {
    setLinks(prev => prev.filter(l => l.id !== id));
    setToast("Link deleted");
  }, []);

  const filtered = links.filter(l =>
    l.url.toLowerCase().includes(search.toLowerCase()) ||
    l.slug.toLowerCase().includes(search.toLowerCase())
  );

  const NAV = [
    { id: "home", label: "Shorten" },
    { id: "links", label: `Links (${links.length})` },
    { id: "docs", label: "API Docs" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "#080808", color: "#e0e0e0", fontFamily: "'Space Grotesk', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700;800&family=DM+Mono:wght@400;500&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: #111; }
        ::-webkit-scrollbar-thumb { background: #2a2a2a; border-radius: 2px; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }
        @keyframes scaleIn { from { opacity: 0; transform: scale(.95); } to { opacity: 1; transform: none; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: none; } }
        @keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: .4; } }
        @keyframes spin { to { transform: rotate(360deg); } }
        input::placeholder { color: #333; }
      `}</style>

      {/* ── Nav ── */}
      <nav style={{
        position: "sticky", top: 0, zIndex: 50,
        background: "#080808dd", backdropFilter: "blur(16px)",
        borderBottom: "1px solid #141414",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "0 28px", height: 56
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
          <div style={{
            width: 30, height: 30, borderRadius: 8,
            background: "linear-gradient(135deg, #00f5a0, #00d4e0)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 15
          }}>⚡</div>
          <span style={{ fontWeight: 800, fontSize: 17, letterSpacing: -.4 }}>
            snip<span style={{ color: "#00f5a0" }}>.ly</span>
          </span>
        </div>

        <div style={{ display: "flex", gap: 2 }}>
          {NAV.map(n => (
            <button key={n.id} onClick={() => setView(n.id)} style={{
              background: view === n.id ? "#141414" : "none",
              border: view === n.id ? "1px solid #222" : "1px solid transparent",
              borderRadius: 8, padding: "5px 14px", cursor: "pointer",
              color: view === n.id ? "#eee" : "#555",
              fontSize: 13, fontWeight: 600, transition: "all .15s",
              fontFamily: "inherit"
            }}>{n.label}</button>
          ))}
        </div>

        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <span style={{ fontSize: 11, color: "#444", fontFamily: "'DM Mono', monospace" }}>
            {fmtNum(totalClicks + 1284091)} clicks
          </span>
          <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#00f5a0", animation: "pulse 2s infinite" }} />
        </div>
      </nav>

      {/* ── HOME ── */}
      {view === "home" && (
        <div style={{ maxWidth: 700, margin: "0 auto", padding: "72px 24px 48px", animation: "fadeIn .5s ease" }}>
          <div style={{ textAlign: "center", marginBottom: 48 }}>
            <div style={{ fontSize: 10, letterSpacing: 3.5, color: "#00f5a0", marginBottom: 14, fontFamily: "'DM Mono', monospace" }}>
              ● LIVE · URL SHORTENER · ENTERPRISE GRADE
            </div>
            <h1 style={{
              fontSize: "clamp(34px, 6vw, 54px)", fontWeight: 800, lineHeight: 1.1,
              letterSpacing: -1.5, marginBottom: 18,
              background: "linear-gradient(160deg, #ffffff 0%, #666666 100%)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            }}>
              Short links that<br />mean business
            </h1>
            <p style={{ color: "#4a4a4a", fontSize: 15, lineHeight: 1.7, maxWidth: 380, margin: "0 auto" }}>
              Custom aliases · Real-time analytics · QR codes · REST API. Built for scale.
            </p>
          </div>

          {/* Shorten Box */}
          <div style={{
            background: "#0e0e0e", border: "1px solid #1e1e1e", borderRadius: 16,
            padding: "24px", marginBottom: 16
          }}>
            <label style={{ fontSize: 10, color: "#444", letterSpacing: 1.5, display: "block", marginBottom: 8, fontFamily: "'DM Mono', monospace" }}>
              DESTINATION URL
            </label>
            <input
              ref={inputRef}
              value={url}
              onChange={e => { setUrl(e.target.value); setError(""); }}
              onKeyDown={e => e.key === "Enter" && shorten()}
              placeholder="https://your-very-long-url.com/with/deep/nested/path?query=params"
              style={{
                width: "100%", background: "#141414", border: "1px solid #222",
                borderRadius: 10, padding: "12px 14px", color: "#ddd", fontSize: 13,
                outline: "none", fontFamily: "'DM Mono', monospace",
                marginBottom: 14, transition: "border-color .15s"
              }}
              onFocus={e => e.target.style.borderColor = "#00f5a044"}
              onBlur={e => e.target.style.borderColor = "#222"}
            />

            <div style={{ display: "flex", gap: 10, alignItems: "flex-end" }}>
              <div style={{ flex: 1 }}>
                <label style={{ fontSize: 10, color: "#444", letterSpacing: 1.5, display: "block", marginBottom: 8, fontFamily: "'DM Mono', monospace" }}>
                  CUSTOM ALIAS <span style={{ color: "#2a2a2a" }}>OPTIONAL</span>
                </label>
                <div style={{ display: "flex", alignItems: "center", background: "#141414", border: "1px solid #222", borderRadius: 10, overflow: "hidden" }}>
                  <span style={{ padding: "12px 8px 12px 14px", fontSize: 12, color: "#3a3a3a", fontFamily: "'DM Mono', monospace", whiteSpace: "nowrap" }}>
                    snip.ly/
                  </span>
                  <input
                    value={alias}
                    onChange={e => { setAlias(e.target.value); setError(""); }}
                    onKeyDown={e => e.key === "Enter" && shorten()}
                    placeholder="my-brand"
                    style={{
                      flex: 1, background: "none", border: "none",
                      padding: "12px 14px 12px 0", color: "#ddd",
                      fontSize: 13, outline: "none", fontFamily: "'DM Mono', monospace"
                    }}
                  />
                </div>
              </div>

              <button onClick={shorten} disabled={loading} style={{
                background: loading ? "#0d2a1e" : "linear-gradient(135deg, #00f5a0 0%, #00d4e0 100%)",
                border: "none", borderRadius: 10, padding: "12px 22px",
                color: loading ? "#00f5a0" : "#050f0a",
                fontSize: 13, fontWeight: 800, cursor: loading ? "default" : "pointer",
                fontFamily: "inherit", letterSpacing: .2,
                display: "flex", alignItems: "center", gap: 8,
                transition: "all .2s", whiteSpace: "nowrap",
                boxShadow: loading ? "none" : "0 0 20px #00f5a033"
              }}>
                {loading ? (
                  <>
                    <div style={{ width: 12, height: 12, border: "2px solid #00f5a033", borderTopColor: "#00f5a0", borderRadius: "50%", animation: "spin .7s linear infinite" }} />
                    Creating…
                  </>
                ) : "⚡ Shorten URL"}
              </button>
            </div>

            {error && (
              <div style={{ marginTop: 10, fontSize: 12, color: "#ff6060", fontFamily: "'DM Mono', monospace", display: "flex", alignItems: "center", gap: 6 }}>
                ⚠ {error}
              </div>
            )}
          </div>

          {/* Stats strip */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 36 }}>
            {[
              { icon: "🔗", label: "Links Created", val: fmtNum(links.length + 24819) },
              { icon: "👆", label: "Total Clicks", val: fmtNum(totalClicks + 1284091) },
              { icon: "⚡", label: "Uptime SLA", val: "99.99%" },
            ].map(s => (
              <div key={s.label} style={{
                background: "#0e0e0e", border: "1px solid #1a1a1a", borderRadius: 12,
                padding: "16px 18px", textAlign: "center"
              }}>
                <div style={{ fontSize: 18, marginBottom: 5 }}>{s.icon}</div>
                <div style={{ fontSize: 19, fontWeight: 800, color: "#eee", fontFamily: "'DM Mono', monospace" }}>{s.val}</div>
                <div style={{ fontSize: 10, color: "#3a3a3a", marginTop: 3, letterSpacing: .5 }}>{s.label}</div>
              </div>
            ))}
          </div>

          {/* Feature grid */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            {[
              { icon: "📊", title: "Real-time Analytics", desc: "Track clicks by geo, device, and browser with live-updating dashboards." },
              { icon: "🎯", title: "Custom Aliases", desc: "Branded short links like snip.ly/launch for trust and brand recall." },
              { icon: "📱", title: "QR Code Generation", desc: "Auto-generated QR codes for every link — perfect for print & offline." },
              { icon: "🔒", title: "Enterprise Security", desc: "HTTPS, rate limiting, spam detection, link expiry, and audit logs." },
              { icon: "🌐", title: "Global CDN", desc: "Sub-millisecond redirects via edge nodes in 50+ countries worldwide." },
              { icon: "🔌", title: "REST & Webhooks", desc: "Full API access with webhooks for click events. SDKs for JS, Python, Go." },
            ].map(f => (
              <div key={f.title} style={{
                background: "#0e0e0e", border: "1px solid #1a1a1a", borderRadius: 12, padding: "18px 20px",
                transition: "border-color .2s"
              }}
                onMouseEnter={e => e.currentTarget.style.borderColor = "#2a2a2a"}
                onMouseLeave={e => e.currentTarget.style.borderColor = "#1a1a1a"}
              >
                <div style={{ fontSize: 20, marginBottom: 8 }}>{f.icon}</div>
                <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 5, color: "#ddd" }}>{f.title}</div>
                <div style={{ fontSize: 12, color: "#484848", lineHeight: 1.6 }}>{f.desc}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── LINKS ── */}
      {view === "links" && (
        <div style={{ maxWidth: 780, margin: "0 auto", padding: "40px 24px", animation: "fadeIn .4s ease" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
            <div>
              <h2 style={{ fontSize: 21, fontWeight: 800, letterSpacing: -.5 }}>Your Links</h2>
              <div style={{ fontSize: 12, color: "#444", marginTop: 2 }}>{links.length} links · {fmtNum(totalClicks)} total clicks</div>
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search links…"
                style={{
                  background: "#111", border: "1px solid #1e1e1e", borderRadius: 9,
                  padding: "8px 14px", color: "#ccc", fontSize: 12, outline: "none",
                  fontFamily: "inherit", width: 200
                }}
              />
              <button onClick={() => setView("home")} style={{
                background: "linear-gradient(135deg, #00f5a0, #00d4e0)",
                border: "none", borderRadius: 9, padding: "8px 16px",
                color: "#050f0a", fontSize: 12, fontWeight: 800,
                cursor: "pointer", fontFamily: "inherit"
              }}>+ New</button>
            </div>
          </div>

          {filtered.length === 0 ? (
            <div style={{ textAlign: "center", padding: "70px 0", color: "#2a2a2a" }}>
              <div style={{ fontSize: 44, marginBottom: 14 }}>🔗</div>
              <div style={{ fontSize: 14 }}>{search ? "No links match your search" : "No links yet — shorten your first URL!"}</div>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {filtered.map(link => (
                <LinkCard key={link.id} link={link}
                  onOpen={setSelected}
                  onCopy={copyLink}
                  onDelete={deleteLink}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── API DOCS ── */}
      {view === "docs" && (
        <div style={{ maxWidth: 720, margin: "0 auto", padding: "40px 24px", animation: "fadeIn .4s ease" }}>
          <h2 style={{ fontSize: 21, fontWeight: 800, letterSpacing: -.5, marginBottom: 6 }}>REST API Reference</h2>
          <p style={{ color: "#444", fontSize: 13, marginBottom: 32, lineHeight: 1.6 }}>
            Integrate snip.ly into your stack. Base URL: <code style={{ fontFamily: "'DM Mono', monospace", color: "#00f5a0" }}>https://api.snip.ly/v1</code>
          </p>

          {[
            {
              method: "POST", path: "/shorten", color: "#7fff7f", bg: "#0a1a0a", desc: "Create a short link",
              body: `{\n  "url": "https://your-long-url.com/path",\n  "alias": "my-link",     // optional\n  "expires_at": "2025-12-31" // optional\n}`,
              resp: `{\n  "id": "clx8abc123",\n  "short_url": "https://snip.ly/my-link",\n  "original_url": "https://your-long-url.com",\n  "created_at": "2024-06-01T12:00:00Z",\n  "expires_at": null\n}`
            },
            {
              method: "GET", path: "/links/:id", color: "#7fd4ff", bg: "#0a0e1a", desc: "Retrieve a link",
              body: null,
              resp: `{\n  "id": "clx8abc123",\n  "short_url": "https://snip.ly/my-link",\n  "original_url": "https://your-long-url.com",\n  "clicks": 4823,\n  "active": true\n}`
            },
            {
              method: "GET", path: "/links/:id/stats", color: "#7fd4ff", bg: "#0a0e1a", desc: "Get analytics",
              body: null,
              resp: `{\n  "clicks": 4823,\n  "unique_visitors": 3102,\n  "top_countries": ["IN","US","GB"],\n  "top_referrers": ["google.com","twitter.com"],\n  "top_browsers": ["Chrome","Safari"],\n  "trend": [{"date":"2024-06-01","clicks":120}]\n}`
            },
            {
              method: "DELETE", path: "/links/:id", color: "#ff9f9f", bg: "#1a0a0a", desc: "Delete a link",
              body: null,
              resp: `{ "deleted": true, "id": "clx8abc123" }`
            },
          ].map(ep => (
            <div key={ep.path} style={{
              background: "#0e0e0e", border: "1px solid #1a1a1a", borderRadius: 12,
              overflow: "hidden", marginBottom: 14
            }}>
              <div style={{ padding: "14px 18px", display: "flex", alignItems: "center", gap: 10, borderBottom: "1px solid #141414" }}>
                <span style={{
                  background: ep.bg, color: ep.color,
                  fontSize: 10, fontWeight: 800, padding: "3px 8px", borderRadius: 5,
                  fontFamily: "'DM Mono', monospace", letterSpacing: .5
                }}>{ep.method}</span>
                <code style={{ fontSize: 13, color: "#bbb", fontFamily: "'DM Mono', monospace" }}>{ep.path}</code>
                <span style={{ fontSize: 11, color: "#3a3a3a", marginLeft: "auto" }}>{ep.desc}</span>
              </div>
              <div style={{ padding: "14px 18px", display: "grid", gridTemplateColumns: ep.body ? "1fr 1fr" : "1fr", gap: 12 }}>
                {ep.body && (
                  <div>
                    <div style={{ fontSize: 9, color: "#444", letterSpacing: 1.5, marginBottom: 8, fontFamily: "'DM Mono', monospace" }}>REQUEST BODY</div>
                    <pre style={{ fontSize: 11, color: "#7fd4ff", fontFamily: "'DM Mono', monospace", lineHeight: 1.65, background: "#0a0a0a", padding: 12, borderRadius: 8, overflow: "auto" }}>{ep.body}</pre>
                  </div>
                )}
                <div>
                  <div style={{ fontSize: 9, color: "#444", letterSpacing: 1.5, marginBottom: 8, fontFamily: "'DM Mono', monospace" }}>RESPONSE 200</div>
                  <pre style={{ fontSize: 11, color: "#7fff7f", fontFamily: "'DM Mono', monospace", lineHeight: 1.65, background: "#0a0a0a", padding: 12, borderRadius: 8, overflow: "auto" }}>{ep.resp}</pre>
                </div>
              </div>
            </div>
          ))}

          <div style={{ background: "#0a1a0e", border: "1px solid #1a3020", borderRadius: 12, padding: "16px 20px" }}>
            <div style={{ fontSize: 11, color: "#555", lineHeight: 1.8 }}>
              <span style={{ color: "#00f5a0", fontWeight: 700 }}>Authentication</span> — pass your API key in every request header:<br />
              <code style={{ fontFamily: "'DM Mono', monospace", color: "#7fd4ff", fontSize: 12 }}>Authorization: Bearer snly_live_xxxxxxxxxxxxxxxx</code>
              <br /><br />
              <span style={{ color: "#00f5a0", fontWeight: 700 }}>Rate limits</span> — Free: 100 req/min · Pro: 1,000 req/min · Enterprise: unlimited
            </div>
          </div>
        </div>
      )}

      {/* Modal */}
      {selected && <AnalyticsModal link={selected} onClose={() => setSelected(null)} />}

      {/* Toast */}
      {toast && <Toast msg={toast} onDone={() => setToast(null)} />}
    </div>
  );
}
