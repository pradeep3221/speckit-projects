# Tasks: Create TinyURL Service

**Input**: Design documents from `/specs/001-create-tinyurl/`
**Prerequisites**: plan.md ✅, spec.md ✅, research.md ✅, data-model.md ✅

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2)
- Exact file paths included in all descriptions

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Project initialization, dependencies, and configuration

- [ ] T001 Initialize Node.js project: `package.json` with `"type": "module"`, project metadata, scripts (`start`, `dev`, `test`, `test:coverage`)
- [ ] T002 Install production dependencies: `express`, `better-sqlite3`, `nanoid`, `express-rate-limit`, `helmet`
- [ ] T003 [P] Install dev dependencies: `vitest`, `supertest`
- [ ] T004 [P] Create `vitest.config.js` with test configuration
- [ ] T005 [P] Create `.gitignore` (node_modules, *.db, coverage/, dist/)
- [ ] T006 Create `src/config.js` — configuration module (port, DB path, base URL, rate limit settings, short code length)

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Database, core utilities, and middleware that ALL user stories depend on

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [ ] T007 Create `src/db/schema.sql` — SQL schema for `urls` and `clicks` tables with indexes (per data-model.md)
- [ ] T008 Create `src/db/database.js` — SQLite connection singleton, WAL mode, schema initialization on startup, close handler
- [ ] T009 [P] Create `src/utils/code-generator.js` — nanoid wrapper with custom 62-char alphabet, configurable length (default 6), collision-retry logic (up to 3 attempts)
- [ ] T010 [P] Create `src/middleware/validator.js` — URL validation middleware: format check via `new URL()`, scheme whitelist (http/https), max length (10,000 chars)
- [ ] T011 [P] Create `src/middleware/error-handler.js` — centralized Express error handler: structured JSON error responses, proper status codes, error logging
- [ ] T012 [P] Create `src/middleware/rate-limiter.js` — rate limiting config: 100 req/min for creation endpoints, higher limit for redirects, 429 response with Retry-After header
- [ ] T013 Create `src/app.js` — Express app setup: helmet, JSON body parser, route mounting, error handler (no `listen` — that goes in index.js)
- [ ] T014 Create `src/index.js` — server entry point: import app, initialize database, start listening on configured port, graceful shutdown handler
- [ ] T015 [P] Create `tests/helpers/test-db.js` — test utilities: create in-memory SQLite database, schema initialization, teardown, fresh DB per test

**Checkpoint**: Foundation ready — Express server starts, database initializes, middleware loaded. User story implementation can begin.

---

## Phase 3: User Story 1 — Shorten a URL (Priority: P1) 🎯 MVP

**Goal**: Submit a long URL → receive a unique short code back.

**Independent Test**: `POST /api/v1/urls` with a valid URL returns 201 with a short code. Invalid URLs return 400.

### Tests for User Story 1

- [ ] T016 [P] [US1] Unit tests in `tests/unit/code-generator.test.js` — generates codes of correct length, uses valid characters, retries on collision
- [ ] T017 [P] [US1] Unit tests in `tests/unit/validator.test.js` — accepts valid URLs, rejects invalid format, rejects non-http schemes, rejects over-length
- [ ] T018 [P] [US1] Unit tests in `tests/unit/url-service.test.js` — creates URL record, handles duplicate code retry, validates input
- [ ] T019 [US1] Integration tests in `tests/integration/urls-api.test.js` — POST /api/v1/urls: 201 with valid URL, 400 with invalid URL, 422 with malicious URL, response shape validation

### Implementation for User Story 1

- [ ] T020 [US1] Create `src/services/url-service.js` — `createUrl(originalUrl, customCode?)`: validate URL, generate code (or use custom), insert into DB, return URL record. `getByCode(shortCode)`: lookup by code, return record or null. `listUrls(page, limit)`: paginated query.
- [ ] T021 [US1] Create `src/routes/urls.js` — `POST /api/v1/urls`: parse body, call url-service.createUrl, return 201 with short URL JSON. Validate request body, handle errors (400, 409, 422).
- [ ] T022 [US1] Create `src/routes/health.js` — `GET /health`: return 200 with `{ status: "ok", timestamp }`. Return 503 if DB is not accessible.
- [ ] T023 [US1] Mount routes in `src/app.js` — add `/api/v1/urls` and `/health` routes
- [ ] T024 [US1] Integration test in `tests/integration/health.test.js` — GET /health returns 200 with expected shape

**Checkpoint**: URL shortening works end-to-end. POST a URL → get a short code. Health check responds. This is the MVP core.

---

## Phase 4: User Story 2 — Redirect via Short URL (Priority: P1)

**Goal**: Visit a short URL → instantly redirected to the original URL via HTTP 301.

**Independent Test**: Create a short URL, then GET `/{shortCode}` and verify HTTP 301 with correct Location header.

### Tests for User Story 2

- [ ] T025 [P] [US2] Integration tests in `tests/integration/redirect.test.js` — GET /:code: 301 redirect for valid code, 404 for unknown code, 410 for deactivated URL, Location header matches original URL

### Implementation for User Story 2

- [ ] T026 [US2] Create `src/routes/redirect.js` — `GET /:shortCode`: lookup via url-service.getByCode, if active → 301 redirect with Location header + Cache-Control, if not found → 404 JSON, if inactive → 410 JSON
- [ ] T027 [US2] Mount redirect route in `src/app.js` — add `/:shortCode` AFTER `/api/v1/*` and `/health` routes (order matters to avoid conflicts)

**Checkpoint**: Core URL shortener fully works. Create short URLs and redirect through them. This completes the P1 MVP.

---

## Phase 5: User Story 3 — View Click Analytics (Priority: P2)

**Goal**: Track each redirect as a click event and expose analytics via API.

**Independent Test**: Create a short URL, simulate redirects, query stats endpoint, verify click counts match.

### Tests for User Story 3

- [ ] T028 [P] [US3] Unit tests in `tests/unit/analytics-service.test.js` — records click with metadata, retrieves stats with correct count, handles unknown code
- [ ] T029 [P] [US3] Integration tests in `tests/integration/analytics-api.test.js` — GET /api/v1/urls/:code/stats: 200 with click data, 404 for unknown code, counts increment after redirects

### Implementation for User Story 3

- [ ] T030 [US3] Create `src/services/analytics-service.js` — `recordClick(shortCode, referrer, userAgent)`: insert into clicks table + increment urls.click_count atomically. `getStats(shortCode)`: return totalClicks + click records sorted by clicked_at DESC.
- [ ] T031 [US3] Update `src/routes/redirect.js` — after successful redirect lookup, call analytics-service.recordClick with request headers (referrer, user-agent) before sending 301
- [ ] T032 [US3] Add stats route in `src/routes/urls.js` — `GET /api/v1/urls/:code/stats`: call analytics-service.getStats, return 200 with stats JSON or 404 if code not found

**Checkpoint**: Click analytics work. Redirects are tracked, stats endpoint returns accurate data. P1 + P2 stories complete.

---

## Phase 6: User Story 4 — Custom Short Codes (Priority: P3)

**Goal**: Optionally provide a custom short code when creating a URL.

**Independent Test**: POST with `customCode` field, verify the exact code is used in the response and redirect works.

### Tests for User Story 4

- [ ] T033 [P] [US4] Integration tests — extend `tests/integration/urls-api.test.js`: POST with customCode returns 201 with that code, 409 when code taken, 400 for invalid chars (only allow `[a-zA-Z0-9-]`, 3-30 chars)

### Implementation for User Story 4

- [ ] T034 [US4] Update `src/services/url-service.js` — extend `createUrl` to accept optional `customCode` param: validate format (regex: `/^[a-zA-Z0-9-]{3,30}$/`), check uniqueness, use it instead of generating
- [ ] T035 [US4] Update `src/routes/urls.js` — parse `customCode` from request body, pass to url-service.createUrl, return 409 if code already exists
- [ ] T036 [US4] Update `src/middleware/validator.js` — add custom code validation: alphanumeric + hyphens, 3-30 chars

**Checkpoint**: Custom codes work alongside auto-generated codes.

---

## Phase 7: User Story 5 — List My URLs (Priority: P3)

**Goal**: Paginated list of all created short URLs.

**Independent Test**: Create several URLs, query list endpoint with pagination, verify all returned.

### Tests for User Story 5

- [ ] T037 [P] [US5] Integration tests — extend `tests/integration/urls-api.test.js`: GET /api/v1/urls returns paginated list, respects page/limit params, empty list when none exist, response includes total count

### Implementation for User Story 5

- [ ] T038 [US5] Add list route in `src/routes/urls.js` — `GET /api/v1/urls`: parse `page` (default 1) and `limit` (default 20, max 100) query params, call url-service.listUrls, return 200 with `{ urls: [...], total, page, limit }`

**Checkpoint**: All 5 user stories complete and independently testable.

---


## Phase 8: Polish & Cross-Cutting Concerns

**Purpose**: Security hardening, documentation, final validation, compliance, and non-functional requirements

- [ ] T039 [P] Apply rate limiting in `src/app.js` — attach rate-limiter middleware to `/api/v1/urls` POST route (100/min per IP)
- [ ] T040 [P] Verify helmet is active in `src/app.js` — security headers set on all responses
- [ ] T041 [P] Create `README.md` — project overview, setup instructions (`npm install`, `npm start`), API reference with curl examples, configuration options
- [ ] T042 Run full test suite with coverage: `npm run test:coverage` — verify all tests pass, minimum 80% coverage (SC-007)
- [ ] T043 End-to-end smoke test: start server, create URL, redirect, check stats, verify health endpoint — all working together

# Compliance, Fallback, and Non-Functional Requirements
- [ ] T044 [P] Implement geocoding fallback and caching logic in `src/services/analytics-service.js` — if primary geocoding fails, use secondary provider or cached result; add tests for fallback/caching
- [ ] T045 [P] Implement audit log compliance: log all create, delete, and redirect actions with timestamp, user agent, and IP (if available) in `src/services/url-service.js` and `src/routes/redirect.js`; ensure logs are retained for 90 days; add tests for audit log
- [ ] T046 [P] Add integration test for redirect latency p99 < 50ms under 1,000 concurrent requests (NFR-001)
- [ ] T047 [P] Add integration test for URL creation p95 < 200ms (NFR-002)
- [ ] T048 [P] Add Lighthouse/WebPageTest script to verify SPA loads < 1.5s on 3G (NFR-003)
- [ ] T049 [P] Add integration test for 1,000 concurrent redirects with zero 5xx errors (NFR-004)
- [ ] T050 [P] Document and verify UI usability: all primary actions discoverable in 2 clicks, feedback within 500ms (NFR-005)

---

## Phase 9: Frontend SPA & UI/UX (P2/P3)

**Purpose**: Implement all frontend requirements for SPA, copy-to-clipboard, search/filter, analytics modal, API docs tab, and dark terminal UI.

- [ ] T044 [P] [FR-012] Implement SPA frontend in `public/index.html` and supporting JS/CSS for dark terminal aesthetic (JetBrains Mono, CRT scanlines, #00ff9f accent, blinking cursor logo, responsive layout)
- [ ] T045 [P] [FR-013] Add one-click copy-to-clipboard for all short URLs with toast confirmation in `public/index.html`/JS
- [ ] T046 [P] [FR-014] Implement search/filter for browsing links by short code or original URL in frontend
- [ ] T047 [P] [FR-015] Render analytics dashboard modal with animated click counter, 14-day SVG sparkline, geo/browser/device bar charts, and SVG QR code preview (mock data, zero external dependencies)
- [ ] T048 [P] [FR-016] Add API documentation tab with collapsible endpoint cards, color-coded method badges, request/response examples, and rate limit tier documentation
- [ ] T049 [P] [FR-008] Ensure all toast notifications (success/error) use correct styling and appear for all user actions (shorten, copy, delete, error)
- [ ] T050 [P] [FR-008] Implement mobile-responsive layout and verify on 320px–1920px viewports

---

## Phase 10: Frontend Test & Verification

**Purpose**: Ensure all frontend features are independently testable and constitutionally compliant (TDD).

- [ ] T051 [P] [FR-012] Manual/automated test: SPA loads with correct dark theme, CRT effect, and responsive layout
- [ ] T052 [P] [FR-013] Test: Copy-to-clipboard works and toast appears on all supported browsers
- [ ] T053 [P] [FR-014] Test: Search/filter returns correct results for various queries
- [ ] T054 [P] [FR-015] Test: Analytics modal renders all tabs, mock data displays correctly, QR code SVG present
- [ ] T055 [P] [FR-016] Test: API docs tab displays all endpoints, examples, and rate limit info

---

## Dependencies & Execution Order


### Phase Dependencies

```
Phase 1 (Setup) ─────────────▶ Phase 2 (Foundation) ─────────────▶ Phase 3+ (User Stories)
                                    ⚠️ BLOCKS ALL                     ▼
                                                              Phase 8 (Polish, Compliance, NFR)
```

### User Story Dependencies

- **US1 (Shorten)**: Depends on Phase 2 only — no other story dependencies
- **US2 (Redirect)**: Depends on Phase 2 + US1 (needs url-service.getByCode)
- **US3 (Analytics)**: Depends on US2 (extends redirect flow with click recording)
- **US4 (Custom Codes)**: Depends on US1 (extends createUrl)
- **US5 (List URLs)**: Depends on US1 (extends url-service with listUrls)

### Recommended Execution Order

```
T001-T006 (Setup) → T007-T015 (Foundation) → T016-T024 (US1) → T025-T027 (US2) → T028-T032 (US3) → T033-T036 (US4) → T037-T038 (US5) → T039-T043 (Polish) → T044-T055 (Frontend)
```

### Parallel Opportunities

- **Phase 1**: T003, T004, T005 can run in parallel
- **Phase 2**: T009, T010, T011, T012 can run in parallel (after T007-T008)
- **Phase 3**: T016, T017, T018 can run in parallel
- **Phase 5**: T028, T029 can run in parallel
- **Phase 8**: T039, T040, T041 can run in parallel
- **Phase 9**: T044, T045, T046, T047, T048, T049, T050 can run in parallel
- **Phase 10**: T051, T052, T053, T054, T055 can run in parallel

---

## Notes

- Total tasks: **43**
- Follow TDD: write tests → verify they fail → implement → verify they pass
- Commit after each phase checkpoint
- Stop at Phase 4 checkpoint for a working MVP (P1 stories only)
- Each phase adds incremental value without breaking previous work
