# API Contracts: snip.ly URL Shortener
aks interface contracts

**Date**: 2026-03-22  
**Feature**: 001-create-tinyurl  
**Base URL**: `http://localhost:3000` (configurable via `BASE_URL` env)  
**API Version**: v1 (`/api/v1/`)

---

## POST /api/v1/urls — Create Short URL

### Request
```
Content-Type: application/json
```
```json
{
  "url": "https://example.com/very/long/path",
  "customCode": "my-link"          // optional, 3-30 chars [a-zA-Z0-9-]
}
```

### Responses

**201 Created**
```json
{
  "shortCode": "abc123",
  "shortUrl": "http://localhost:3000/abc123",
  "originalUrl": "https://example.com/very/long/path",
  "createdAt": "2026-03-22T10:00:00.000Z"
}
```
Headers: `X-Request-Id: <uuid>`

**400 Bad Request** — Invalid URL, bad scheme, too long (>10,000 chars), or invalid custom code format
```json
{
  "error": "Invalid URL format",
  "requestId": "<uuid>"
}
```

**409 Conflict** — Custom code already taken
```json
{
  "error": "Short code 'my-link' is already in use",
  "requestId": "<uuid>"
}
```

**429 Too Many Requests** — Rate limit exceeded (100/min per IP)
```json
{
  "error": "Too many requests, please try again later"
}
```
Headers: `Retry-After: <seconds>`

---

## GET /api/v1/urls — List All URLs (Paginated)

### Request
```
GET /api/v1/urls?page=1&limit=10
```
- `page`: Page number (default: 1, min: 1)
- `limit`: Items per page (default: 10, max: 100)

### Responses

**200 OK**
```json
{
  "urls": [
    {
      "shortCode": "abc123",
      "shortUrl": "http://localhost:3000/abc123",
      "originalUrl": "https://example.com/very/long/path",
      "isActive": true,
      "clickCount": 42,
      "createdAt": "2026-03-22T10:00:00.000Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 42,
    "totalPages": 5
  }
}
```
Headers: `X-Request-Id: <uuid>`

**Sort order**: Newest first (descending by `created_at`).

---

## GET /api/v1/urls/:code/stats — Get Click Analytics

### Request
```
GET /api/v1/urls/abc123/stats
```

### Responses

**200 OK**
```json
{
  "shortCode": "abc123",
  "originalUrl": "https://example.com/very/long/path",
  "totalClicks": 42,
  "clicks": [
    {
      "timestamp": "2026-03-22T10:05:00.000Z",
      "referrer": "https://twitter.com",
      "userAgent": "Mozilla/5.0 ..."
    },
    {
      "timestamp": "2026-03-22T10:06:00.000Z",
      "referrer": null,
      "userAgent": "curl/7.88.1"
    }
  ]
}
```
Headers: `X-Request-Id: <uuid>`

**404 Not Found** — Short code does not exist
```json
{
  "error": "URL not found",
  "requestId": "<uuid>"
}
```

---

## DELETE /api/v1/urls/:code — Soft-Delete URL

### Request
```
DELETE /api/v1/urls/abc123
```

### Responses

**204 No Content** — Successfully deactivated (no response body)
Headers: `X-Request-Id: <uuid>`

**404 Not Found** — Short code does not exist
```json
{
  "error": "URL not found",
  "requestId": "<uuid>"
}
```

---

## GET /:shortCode — Redirect

### Request
```
GET /abc123
```

### Responses

**301 Moved Permanently** — Redirect to original URL
```
Location: https://example.com/very/long/path
Cache-Control: public, max-age=86400
X-Request-Id: <uuid>
```

**404 Not Found** — Short code does not exist
```json
{
  "error": "URL not found",
  "requestId": "<uuid>"
}
```

**410 Gone** — URL has been deactivated (soft-deleted)
```json
{
  "error": "This URL has been deactivated",
  "requestId": "<uuid>"
}
```

**429 Too Many Requests** — Rate limit exceeded (1,000/min per IP)
```json
{
  "error": "Too many requests, please try again later"
}
```
Headers: `Retry-After: <seconds>`

---

## GET /health — Health Check

### Request
```
GET /health
```

### Responses

**200 OK**
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "uptime": 12345.67,
  "timestamp": "2026-03-22T10:00:00.000Z",
  "checks": {
    "database": "ok"
  },
  "memory": {
    "rss": 52428800,
    "heapUsed": 20971520,
    "heapTotal": 41943040
  }
}
```

**503 Service Unavailable** — Database unavailable
```json
{
  "status": "degraded",
  "version": "1.0.0",
  "checks": {
    "database": "error"
  }
}
```

---

## Cross-Cutting Concerns

### Request ID
Every request/response includes `X-Request-Id` header (UUID v4). If the client sends one, the server echoes it; otherwise a new one is generated.

### Rate Limits
| Tier | URL Creation | Redirects |
|------|-------------|-----------|
| Free | 100/min per IP | 1,000/min per IP |
| Pro | (documented, not enforced) | (documented, not enforced) |
| Enterprise | (documented, not enforced) | (documented, not enforced) |

### Error Format
All errors return JSON with `error` (string) and `requestId` (string, except 429):
```json
{
  "error": "Human-readable error message",
  "requestId": "<uuid>"
}
```

### Content Types
- API responses: `application/json`
- Redirect (301): No body, `Location` header
- Static files: Served from `public/` with standard MIME types
