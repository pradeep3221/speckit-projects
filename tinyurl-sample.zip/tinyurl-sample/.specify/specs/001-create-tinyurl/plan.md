# Implementation Plan: snip.ly — Production-Ready URL Shortener

**Branch**: `001-create-tinyurl` | **Date**: 2026-03-22 | **Spec**: [spec.md](./spec.md)
**Input**: Feature specification from `/specs/001-create-tinyurl/spec.md`

## Summary

Build a production-ready URL shortening service (snip.ly) with a dark terminal aesthetic SPA frontend. The backend is a Node.js/Express REST API with SQLite persistence, nanoid for short code generation, pino logging, and helmet security headers. The frontend is a vanilla HTML/CSS/JS single-page application served as a static file. The codebase is **substantially implemented** — this plan addresses the identified gaps and finalizes the remaining work.

## Technical Context

**Language/Version**: Node.js 20 LTS, JavaScript (ES Modules)  
**Primary Dependencies**: Express 4.21, sql.js (WASM SQLite), nanoid 5, express-rate-limit 7, helmet 8, pino 9, pino-http 10, cors, swagger-ui-express 5  
**Storage**: SQLite via sql.js (WebAssembly, file persistence at `./data/urls.db`, WAL mode)  
**Testing**: Vitest 3 (unit + integration), supertest 7 (HTTP endpoint testing), @vitest/coverage-v8  
**Target Platform**: Linux/macOS/Windows (localhost for dev, Docker for production)  
**Project Type**: Web service (REST API) + SPA frontend (vanilla HTML/CSS/JS)  
**Performance Goals**: < 50ms redirect p99 (integration test, CI), < 200ms URL creation p95 (measured, CI), 1,000 concurrent redirects (integration test, CI), SPA loads < 1.5s on 3G (Lighthouse/WebPageTest), UI actions discoverable in 2 clicks with feedback < 500ms (usability test)
**Constraints**: Single-server deployment, < 100MB memory, zero external service dependencies. All error responses MUST use the explicit schema defined in spec.md FR-007. All fallback/caching and audit log requirements MUST be implemented and tested as per spec.md.
**Scale/Scope**: ~15 source files, 5 API endpoints, 1 SPA frontend, ~20 test files  
**Ownership Model**: Public/shared instance — no authentication, all links globally visible  

## Clarification Summary

| # | Question | Answer |
|---|----------|--------|
| Q1 | Link ownership model? | Public/shared, no auth. "My Links" shows all links. |
| Q2 | Database technology + persistence? | SQLite file-based (sql.js), WAL mode. |
| Q3 | Delete confirmation UX? | Browser native `confirm()` dialog. |
| Q4 | Custom alias length asymmetry? | Keep: frontend 3–20, API 3–30. |
| Q5 | Default sort order for link list? | Newest first (DESC by `created_at`). |

## Constitution Check

| Principle | Status | Notes |
|-----------|--------|-------|
| I. Simplicity First | ✅ Pass | Minimal stack: Express + sql.js + nanoid. No ORM, no Redis, no message queues. Single HTML file for frontend. |
| II. Performance & Reliability | ✅ Pass | SQLite reads are sub-millisecond; redirect path is a single DB lookup + HTTP 301. Graceful shutdown implemented. Analytics failure doesn't block redirects. |
| III. Test-Driven Development | ✅ Pass | Vitest + supertest with 80% coverage thresholds enforced in vitest.config.js. Unit + integration tests exist for all service/route layers. |
| IV. Security by Default | ✅ Pass | URL validation (scheme, format, length), rate limiting (express-rate-limit), helmet for headers, nanoid for unpredictable codes. No sequential IDs. |
| V. Clean API Design | ✅ Pass | RESTful, versioned (`/api/v1/`), JSON responses, proper HTTP status codes, X-Request-Id tracing, OpenAPI/Swagger docs. |

- **No constitution violations detected.** All five principles are satisfied. All non-functional requirements are mapped to measurable criteria and must be covered by tasks.
- **Note**: Constitution III mandates TDD (tests first). Existing tests cover the implemented features; the gaps identified below need test updates in parallel.

## Codebase Audit — Current State

### ✅ Already Implemented & Working
| Area | Details |
|------|---------|
| URL shortening | POST `/api/v1/urls` with Base62 (nanoid custom alphabet), collision retry (3 attempts) |
| Custom aliases | 3–30 chars `[a-zA-Z0-9-]` with uniqueness enforcement (409 on conflict) |
| Redirect | GET `/:shortCode` → 301 with `Cache-Control: public, max-age=86400` |
| Soft-delete | DELETE `/api/v1/urls/:code` → 204; redirect returns 410 Gone |
| Click analytics | Records referrer + user-agent; GET `/api/v1/urls/:code/stats` |
| Health check | GET `/health` with DB probe, memory stats, uptime |
| Pagination | `page` + `limit` params, clamped to max 100 |
| X-Request-Id | UUID v4, echoed in response, included in error bodies |
| Pino logging | Structured JSON, request correlation, header redaction |
| Rate limiting (creation) | 100/min per IP via express-rate-limit |
| Security headers | helmet 8 |
| SPA frontend | Full dark terminal aesthetic (JetBrains Mono, CRT scanlines, #00ff9f, tabs, analytics modal, copy, delete, search) |
| Swagger/OpenAPI | Served at `/api-docs` |
| Graceful shutdown | SIGINT/SIGTERM with drain timeout |
| Docker | Multi-stage build, node:20-alpine, non-root user |
| Tests | Unit (url-service, analytics-service, code-generator, validator) + integration (urls-api, redirect, analytics-api, health) |

### ⚠️ Gaps Requiring Fixes

| ID | Gap | Impact | Fix |
|----|-----|--------|-----|
| GAP-001 | Short code length defaults to **7**; spec requires **6** | FR-001, SC-006 violated | Change `config.js` shortCodeLength to 6; update all test assertions |
| GAP-002 | `redirectLimiter` defined but **never wired** to redirect route | FR-006 violated (redirects unprotected) | Add `redirectLimiter` middleware to redirect route in `app.js` |
| GAP-003 | Dockerfile missing `COPY` for `public/` directory | FR-012 violated in Docker deployments | Add `COPY --from=builder /app/public ./public` to Dockerfile |
| GAP-004 | Swagger doc says `[a-zA-Z0-9_-]` (includes underscore); spec says hyphens only | Inconsistent documentation | Fix swagger.js pattern to `[a-zA-Z0-9-]` |

## Project Structure

### Documentation (this feature)

```text
.specify/specs/001-create-tinyurl/
├── spec.md              # Feature specification (with clarifications)
├── plan.md              # This file — implementation plan
├── research.md          # Technology research + resolved unknowns
├── data-model.md        # Database schema design + validation rules
├── contracts/
│   └── api-contracts.md # REST API request/response contracts
├── quickstart.md        # Developer quick-start guide
├── tasks.md             # Task breakdown (created by /speckit.tasks)
└── url-shortener.jsx    # Frontend reference component
```

### Source Code (repository root)

```text
src/
├── index.js             # Application entry point, server startup, graceful shutdown
├── app.js               # Express app: middleware pipeline + route mounting
├── config.js            # Configuration (port, DB path, rate limits, base URL, code length)
├── logger.js            # Pino structured logger configuration
├── swagger.js           # OpenAPI 3.0.3 specification (served at /api-docs)
├── routes/
│   ├── urls.js          # POST /api/v1/urls, GET /api/v1/urls, GET /:code/stats, DELETE /:code
│   ├── redirect.js      # GET /:shortCode → 301 redirect (+ click recording)
│   └── health.js        # GET /health
├── services/
│   ├── url-service.js   # Business logic: create, resolve, list, soft-delete URLs
│   └── analytics-service.js  # Business logic: record click, get stats
├── db/
│   ├── database.js      # sql.js connection, init, save, close, setDatabase (test helper)
│   └── schema.sql       # Table definitions (urls, clicks, indexes)
├── middleware/
│   ├── rate-limiter.js  # createLimiter (100/min) + redirectLimiter (1000/min)
│   ├── error-handler.js # Centralized error handling + createHttpError utility
│   ├── request-id.js    # X-Request-Id generation/propagation
│   └── validator.js     # URL validation + custom code validation
└── utils/
    └── code-generator.js # nanoid wrapper (Base62, 6-char, 3 collision retries)

public/
└── index.html           # SPA frontend (vanilla HTML/CSS/JS, dark terminal aesthetic)

tests/
├── unit/
│   ├── url-service.test.js
│   ├── analytics-service.test.js
│   ├── code-generator.test.js
│   └── validator.test.js
├── integration/
│   ├── urls-api.test.js
│   ├── redirect.test.js
│   ├── analytics-api.test.js
│   └── health.test.js
└── helpers/
    └── test-db.js       # In-memory SQLite test setup/teardown

package.json             # Dependencies, scripts, ESM config
vitest.config.js         # Test config: 80% coverage thresholds
eslint.config.js         # ESLint flat config
Dockerfile               # Multi-stage Docker build
README.md                # Project overview
```

## API Design


### Endpoints

| Method | Path | Description | Status Codes | Error Schema |
|--------|------|-------------|-------------|-------------|
| `POST` | `/api/v1/urls` | Create a short URL (auto or custom code) | 201, 400, 409, 429 | All errors use explicit schema |
| `GET` | `/api/v1/urls` | List all URLs (paginated, newest first) | 200 | — |
| `GET` | `/api/v1/urls/:code/stats` | Get click analytics for a short code | 200, 404 | All errors use explicit schema |
| `DELETE` | `/api/v1/urls/:code` | Soft-delete (deactivate) a URL | 204, 404 | All errors use explicit schema |
| `GET` | `/:shortCode` | Redirect to original URL | 301, 404, 410, 429 | All errors use explicit schema |
| `GET` | `/health` | Health check with DB probe | 200, 503 | All errors use explicit schema |

Full request/response contracts: [contracts/api-contracts.md](./contracts/api-contracts.md)

### Request/Response Examples

**Create Short URL**
```json
// POST /api/v1/urls
// Request:
{ "url": "https://example.com/very/long/path", "customCode": "my-link" }

// Response (201):
{
  "shortCode": "my-link",
  "shortUrl": "http://localhost:3000/my-link",
  "originalUrl": "https://example.com/very/long/path",
  "createdAt": "2026-03-22T10:00:00.000Z"
}
```

**Get Analytics**
```json
// GET /api/v1/urls/my-link/stats
// Response (200):
{
  "shortCode": "my-link",
  "originalUrl": "https://example.com/very/long/path",
  "totalClicks": 42,
  "clicks": [
    { "timestamp": "2026-03-22T10:05:00.000Z", "referrer": "https://twitter.com", "userAgent": "..." }
  ]
}
```

## Database Schema

See [data-model.md](./data-model.md) for full schema, validation rules, and query patterns.

### Tables
- **`urls`**: short_code (UNIQUE), original_url, is_active, click_count (denormalized), created_at
- **`clicks`**: short_code (FK), referrer, user_agent, clicked_at

### Key Indexes
- `idx_urls_short_code` — fast redirect lookups
- `idx_clicks_short_code` — fast analytics queries
- `idx_clicks_clicked_at` — time-range queries


### Key Technical Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Database | SQLite (sql.js WASM) | Zero config, no compilation needed, file persistence, WAL mode. Meets < 50ms redirect. |
| Short code generation | nanoid (custom Base62 alphabet) | Cryptographically random, configurable length, URL-safe. Unpredictable per Constitution IV. |
| Code length | **6 characters** | 62⁶ = ~56.8 billion combinations. Zero realistic collision risk. Matches spec FR-001. |
| Redirect type | HTTP 301 (permanent) | Standard for URL shorteners. `Cache-Control: public, max-age=86400` for CDN. |
| Rate limiting | express-rate-limit (in-memory) | Simple, no Redis. 100/min create, 1,000/min redirect. Single-server sufficient. |
| Click tracking | Synchronous insert, failure-tolerant | Ensures accuracy (SC-005). Failures logged but don't block redirects (FR-004). |
| API versioning | URL path (`/api/v1/`) | Simple, explicit, no header negotiation. |
| Frontend | Vanilla HTML/CSS/JS (single file) | No build step, no framework. Dark terminal aesthetic. Per Constitution I. |
| Logging | pino + pino-http | Fastest JSON logger. Request correlation, header redaction. |
| Ownership | Public/shared (no auth) | Simplest model for demo scope. Can layer auth later. |
| Error Handling | Explicit error schema | All error responses use the schema in spec.md FR-007. |
| Fallback/Caching | Geocoding fallback/caching logic | If primary geocoding fails, use secondary/cached provider. All logic covered by tests. |
| Audit Log | All create, delete, redirect actions logged | Retain logs for 90 days, testable and documented. |


## Implementation Phases

### Phase 1: Fix Identified Gaps (Critical)

These are spec violations in the existing codebase that must be fixed before the feature is complete.

| Task | File(s) | Effort |
|------|---------|--------|
| 1.1 Change shortCodeLength from 7 → 6 | `src/config.js` | 1 min |
| 1.2 Update all test assertions from length 7 → 6 | `tests/unit/code-generator.test.js`, `tests/unit/url-service.test.js`, `tests/integration/urls-api.test.js` | 10 min |
| 1.3 Wire `redirectLimiter` to redirect route | `src/app.js` | 2 min |
| 1.4 Add redirect rate-limit integration test | `tests/integration/redirect.test.js` | 5 min |
| 1.5 Fix Dockerfile to copy `public/` | `Dockerfile` | 1 min |
| 1.6 Fix swagger.js custom code pattern (remove underscore) | `src/swagger.js` | 2 min |
| 1.7 Run full test suite, verify 80%+ coverage | — | 5 min |

**Estimated effort**: ~30 minutes

### Phase 2: Verification & Polish

| Task | Details |
|------|---------|
| 2.1 End-to-end smoke test | Start server, shorten URL, redirect, view analytics, delete, verify 410 |
| 2.2 Frontend verification | Test all tabs (Shorten, My Links, API Docs), analytics modal, copy, search, mobile viewport |
| 2.3 Docker build + run verification | Build image, run container, verify SPA + API + health |
| 2.4 Coverage report review | Ensure 80%+ on statements, branches, functions, lines |

### Phase 3: Future Iterations (Out of Scope)

These items are documented for future work but are **not** part of this feature branch:

- User authentication and per-user link scoping
- URL reactivation (undo soft-delete)
- Real GeoIP lookup for analytics (currently mock data)
- Scan-functional QR codes (currently decorative SVG)
- Pro/Enterprise rate limit tier enforcement
- Redis-backed rate limiting for multi-instance deployment
- PostgreSQL migration for horizontal scaling

## Constitution Check — Post-Design

| Principle | Status | Notes |
|-----------|--------|-------|
| I. Simplicity First | ✅ Pass | No new dependencies added. Fixes are minimal, targeted edits. |
| II. Performance & Reliability | ✅ Pass | 6-char codes still provide 56.8B namespace. Redirect limiter protects against abuse. |
| III. Test-Driven Development | ✅ Pass | All gap fixes include corresponding test updates. 80% coverage threshold enforced. |
| IV. Security by Default | ✅ Pass | Redirect rate limiter now wired. Swagger docs corrected to match actual validation. |
| V. Clean API Design | ✅ Pass | No API contract changes. Swagger/validator/spec now consistent. |

**No gate violations. Plan is ready for task breakdown and implementation.**

## Dependencies

```json
{
  "dependencies": {
    "express": "^4.21.0",
    "better-sqlite3": "^11.0.0",
    "nanoid": "^5.0.0",
    "express-rate-limit": "^7.0.0",
    "helmet": "^8.0.0"
  },
  "devDependencies": {
    "vitest": "^3.0.0",
    "supertest": "^7.0.0"
  }
}
```

## Complexity Tracking

No constitution violations. All choices follow Simplicity First and minimal dependency principles.
