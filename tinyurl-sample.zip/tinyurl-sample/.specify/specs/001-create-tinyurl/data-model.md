# Data Model: snip.ly — Production-Ready URL Shortener

**Date**: 2026-03-22  
**Feature**: 001-create-tinyurl  
**Storage**: SQLite (via sql.js — WebAssembly-based, file persistence at `./data/urls.db`)  
**Ownership**: Public/shared instance — no user_id column, all links globally visible

## Entity Relationship

```
┌──────────────┐       1:N       ┌──────────────┐
│     urls     │────────────────▶│    clicks     │
│              │                 │               │
│ short_code   │◀────FK──────── │ short_code    │
│ original_url │                 │ referrer      │
│ is_active    │                 │ user_agent    │
│ click_count  │                 │ clicked_at    │
│ created_at   │                 └───────────────┘
└──────────────┘
```

## Schema Definition (SQLite)

```sql
-- Enable WAL mode for better concurrent read performance
PRAGMA journal_mode=WAL;

-- URL mappings
CREATE TABLE IF NOT EXISTS urls (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    short_code  TEXT    UNIQUE NOT NULL,
    original_url TEXT   NOT NULL,
    is_active   INTEGER DEFAULT 1,       -- 1 = active, 0 = deactivated
    click_count INTEGER DEFAULT 0,       -- denormalized counter for fast reads
    created_at  TEXT    DEFAULT (datetime('now'))
);

-- Click analytics events
CREATE TABLE IF NOT EXISTS clicks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    short_code  TEXT    NOT NULL,
    referrer    TEXT,                     -- nullable: not always present
    user_agent  TEXT,                     -- nullable: may be stripped
    clicked_at  TEXT    DEFAULT (datetime('now')),
    FOREIGN KEY (short_code) REFERENCES urls(short_code) ON DELETE CASCADE
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_urls_short_code   ON urls(short_code);
CREATE INDEX IF NOT EXISTS idx_clicks_short_code ON clicks(short_code);
CREATE INDEX IF NOT EXISTS idx_clicks_clicked_at ON clicks(clicked_at);
```

## Design Decisions

### Denormalized `click_count`
The `urls.click_count` column duplicates data derivable from `COUNT(*)` on `clicks`. This is intentional:
- Redirect path reads `click_count` in the same query that fetches the URL — no join needed.
- Stats endpoint can return total clicks without counting millions of rows.
- Updated atomically via `UPDATE urls SET click_count = click_count + 1` on each click.

### `is_active` Flag (Soft Delete)
- URLs are never physically deleted; `is_active = 0` means deactivated.
- Redirect logic checks `is_active`: if 0, returns HTTP 410 (Gone).
- Preserves analytics data and audit trail per constitution (Data Integrity).

### Text Timestamps
SQLite stores timestamps as TEXT in ISO 8601 format (`datetime('now')`).
- Human-readable in raw DB queries.
- Sortable as strings.
- No timezone issues — always UTC.

## Query Patterns

| Operation | Query | Expected Performance |
|-----------|-------|---------------------|
| Create URL | `INSERT INTO urls (short_code, original_url) VALUES (?, ?)` | < 1ms |
| Resolve redirect | `SELECT original_url, is_active FROM urls WHERE short_code = ?` | < 0.1ms |
| Record click | `INSERT INTO clicks (...) + UPDATE urls SET click_count = click_count + 1` | < 2ms |
| Get stats | `SELECT * FROM clicks WHERE short_code = ? ORDER BY clicked_at DESC` | < 5ms (indexed) |
| List URLs | `SELECT * FROM urls ORDER BY created_at DESC LIMIT ? OFFSET ?` | < 5ms |
| Check code exists | `SELECT 1 FROM urls WHERE short_code = ?` | < 0.1ms |
| Soft-delete URL | `UPDATE urls SET is_active = 0 WHERE short_code = ?` | < 1ms |

## Validation Rules

| Field | Rule | Source |
|-------|------|--------|
| `urls.short_code` (auto) | 6-char Base62 (`[0-9A-Za-z]`), collision-safe (3 retries) | FR-001, SC-006 |
| `urls.short_code` (custom, API) | 3–30 chars, `[a-zA-Z0-9-]`, UNIQUE constraint | FR-007, Clarification Q4 |
| `urls.short_code` (custom, frontend) | 3–20 chars, `[a-zA-Z0-9-]` | FR-007, Clarification Q4 |
| `urls.original_url` | Valid URL, http/https only, max 10,000 chars | FR-003 |
| `urls.is_active` | 0 or 1 (boolean) | FR-011 |

## State Transitions

```
URL Created (is_active=1)
    │
    ├─→ Redirect (301) ─→ Click recorded
    │
    └─→ Soft Delete (is_active=0)
            │
            └─→ Redirect attempt (410 Gone)
```

No reactivation path is defined. Soft-deleted URLs cannot be restored in the current spec.
