# Feature Specification: snip.ly — Production-Ready URL Shortener

**Feature Branch**: `001-create-tinyurl`  
**Created**: 2026-03-22  
**Status**: Draft  
**Input**: Build a production-ready URL shortening service (snip.ly) with a sleek dark terminal aesthetic frontend. Core features include URL shortening with a 900ms simulated async call, custom aliases (3–20 chars with uniqueness check), one-click copy with toast confirmation, and full link management (search, delete, browse). Includes an analytics dashboard with total clicks, 14-day sparkline trend chart, geo/browser/device segmentation, and SVG QR code generation. Ships with an API docs tab, production architecture notes, and edge-ready redirect logic.

**Note**: "Production-ready" means all Functional Requirements (FR) and Success Criteria (SC) are met; the SLA is aspirational only (see Assumptions).

## Clarifications

### Session 2026-03-22

- Q: What is the link ownership model — does "My Links" require authentication or user identity? → A: Public/shared instance with no authentication; "My Links" shows all links in the system.
- Q: What database technology is used, and must data survive container restarts? → A: SQLite file-based persistence (zero external dependencies, single-process, WAL mode for concurrent reads).
- Q: What delete confirmation UX pattern should be used? → A: Browser native `confirm()` dialog.
- Q: Should custom alias length limits differ between frontend (3–20) and API (3–30)? → A: Yes, keep the asymmetry. Frontend enforces 3–20 for simplicity; API allows 3–30 for power-user flexibility.
- Q: What is the default sort order for the link list? → A: Newest first (descending by `created_at`). Matches existing implementation.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Shorten a URL (Priority: P1)

As a user, I want to paste a long URL into the snip.ly interface and receive a short, unique link instantly so that I can share it easily. The shortening experience should feel responsive with a 900ms simulated async call, and the short URL should use a compact 6-char Base62 code (e.g., `snip.ly/abc123`). The original URL must be validated before accepting.

**Why this priority**: This is the core value proposition — without URL shortening, there is no product.

**Independent Test**: Can be fully tested by POSTing a valid URL to the API and verifying a short code is returned. The short code must be unique and unpredictable. Can also be tested end-to-end through the SPA frontend.

**Acceptance Scenarios**:

1. **Given** a valid long URL (e.g., `https://example.com/very/long/path`), **When** the user pastes it into the URL input field and clicks "SHORTEN →", **Then** the system shows a loading state for ~900ms, then displays the shortened URL in a result card with the short code and a copy button (HTTP 201 from API).
2. **Given** an invalid URL (e.g., `not-a-url`), **When** the user submits it, **Then** the system returns HTTP 400 with a clear error message (e.g., 'Invalid URL format') displayed as a toast notification.
3. **Given** a URL that has already been shortened, **When** the user submits the same URL again, **Then** the system returns a new, different short code (each submission creates a unique entry).
4. **Given** a non-http(s) URL (e.g., `ftp://files.example.com`), **When** the user submits it, **Then** the system rejects it with HTTP 400 indicating only http and https URLs are allowed.

---

### User Story 2 - Redirect via Short URL (Priority: P1)

As a user, I want to visit a short URL and be instantly redirected to the original long URL so the short link works seamlessly when shared.

**Why this priority**: Redirect is the other half of the core loop — shortening is useless if redirects don't work.

**Independent Test**: Create a short URL, then GET the short code path and verify HTTP 301 redirect to the original URL.

**Acceptance Scenarios**:

1. **Given** a valid short code that exists, **When** a user visits `GET /{shortCode}`, **Then** the system responds with HTTP 301 redirect to the original URL.
2. **Given** a short code that does not exist, **When** a user visits it, **Then** the system returns HTTP 404 with a user-friendly JSON error response (API, see explicit schema below) or a styled error screen (SPA frontend).
3. **Given** a short code for a URL that has been deactivated, **When** a user visits it, **Then** the system returns HTTP 410 (Gone).

---

### User Story 3 - View Click Analytics Dashboard (Priority: P2)

As a user, I want to click the 📊 button on any link to open a rich analytics dashboard showing total clicks, a 14-day sparkline trend chart, geographic breakdown by country with horizontal bar charts, browser and device segmentation tabs, and a QR code preview — so I can understand link performance at a glance.

**Why this priority**: Analytics add significant value on top of the core shortening/redirect loop. The visual dashboard with geo/browser/device breakdowns and QR codes differentiates snip.ly from basic shorteners.

**Independent Test**: Create a short URL, simulate several redirects, then open the analytics modal and verify:
	- Click counter animates to correct total
	- Sparkline renders 14 data points
	- Geo/browser/device tabs show bar charts
	- QR code SVG renders
	- Modal and all stats load within 500ms of clicking 📊 (API + render)

**Acceptance Scenarios**:

1. **Given** a short URL that has been clicked 5 times, **When** the user clicks the 📊 button on that link in the My Links tab, **Then** the analytics modal opens showing an animated counter reaching `5`, a 14-day sparkline trend chart, and geo/browser/device segmentation tabs.
2. **Given** a short URL with zero clicks, **When** the user opens its analytics, **Then** the modal shows `0` total clicks, a flat sparkline, and the geo/browser/device tabs still render.
3. **Given** an open analytics modal, **When** the user clicks the QR Code tab, **Then** an SVG QR code is rendered (no external dependencies) with a "Copy Link" button below it.
4. **Given** an invalid short code, **When** the user queries stats via the API, **Then** the system returns HTTP 404.

---

### User Story 4 - Custom Aliases (Priority: P2)

As a user, I want to optionally provide my own custom alias (e.g., `snip.ly/launch`) so I can create memorable, branded links. The alias field should show the `snip.ly/` prefix and validate for 3–20 characters (frontend) or 3–30 (API), alphanumeric with hyphens only, with a uniqueness check.

**Why this priority**: Branded slugs are a key differentiator for a production link shortener and are shown prominently in the UI.

**Independent Test**: Submit a URL with a custom alias, verify it's accepted, then test redirect works with that custom code.

**Acceptance Scenarios**:

1. **Given** a valid URL and a custom alias `launch`, **When** submitted via the frontend or `POST /api/v1/urls` with `customCode: "launch"`, **Then** the system creates the short URL with that exact code (HTTP 201).
2. **Given** a custom alias that is already taken, **When** submitted, **Then** the system returns HTTP 409 (Conflict) with a toast message indicating the code is unavailable.
3. **Given** a custom alias with invalid characters (e.g., spaces, special chars), **When** submitted, **Then** the system returns HTTP 400 with validation details shown as a toast.
4. **Given** a custom alias shorter than 3 or longer than 20 characters, **When** submitted via the frontend, **Then** client-side validation prevents submission with a toast message. The API allows 3–30 chars.

---

### User Story 5 - Copy to Clipboard (Priority: P2)

As a user, I want to copy any shortened URL to my clipboard with one click and receive a toast confirmation so I can quickly paste it elsewhere.

**Why this priority**: Copy-to-clipboard is essential for the core sharing workflow and reduces friction.

**Independent Test**: Shorten a URL, click the Copy button on the result card, and verify clipboard contents match the short URL and a success toast appears.

**Acceptance Scenarios**:

1. **Given** a newly shortened URL is displayed in the result card, **When** the user clicks the "Copy" button, **Then** the short URL is written to the clipboard and a toast shows "Copied to clipboard ✓".
2. **Given** a link card in the My Links tab, **When** the user clicks the 📋 button or the short URL text, **Then** the short URL is copied and a toast confirms "Copied ✓".
3. **Given** clipboard access is denied by the browser, **When** the user attempts to copy, **Then** a toast shows "Copy failed" in error style.

---

### User Story 6 - Link Management (Priority: P2)

As a user, I want to search, browse, and delete shortened links from the My Links tab so I can manage them in one place. The system has no authentication — "My Links" displays all links globally.

**Why this priority**: Management features are essential for any non-trivial usage and enable users to maintain their link inventory.

**Independent Test**: Create several short URLs, switch to My Links tab, verify all are listed with search/filter working, and delete one to confirm it's removed.

**Acceptance Scenarios**:

1. **Given** 15 short URLs exist in the system, **When** the user switches to the My Links tab, **Then** all links are displayed with short URL, original URL (truncated), creation date, active status, and click count (no ownership filtering — all links are visible to all users).
2. **Given** the My Links tab is showing all links, **When** the user types into the search box, **Then** links are filtered in real-time by short code or original URL.
3. **Given** a link card with a 🗑 delete button, **When** the user clicks it and confirms via the browser's native `confirm()` dialog, **Then** the link is soft-deleted via `DELETE /api/v1/urls/:code` (HTTP 204), removed from the list, and a success toast appears.
4. **Given** no URLs have been created, **When** the user opens My Links, **Then** an empty state is shown with "No links yet. Shorten your first URL!".
5. **Given** a user queries the list API `GET /api/v1/urls?page=1&limit=10`, **Then** the first 10 URLs are returned with pagination metadata.

---

### User Story 7 - API Documentation Tab (Priority: P3)

As a developer, I want to view a full REST API reference directly within the snip.ly interface so I can integrate programmatically without leaving the app.

**Why this priority**: API docs improve developer experience but don't affect core end-user functionality.

**Independent Test**: Switch to the API Docs tab and verify all endpoints are documented with method badges, request/response examples, and rate limit tiers.

**Acceptance Scenarios**:

1. **Given** the user clicks the "API Docs" tab, **Then** they see collapsible cards for `POST /api/v1/urls`, `GET /api/v1/urls`, `GET /api/v1/urls/:code/stats`, and `DELETE /api/v1/urls/:code` with color-coded method badges (green for POST, blue for GET, red for DELETE).
2. **Given** a user expands the POST endpoint card, **Then** they see the request body schema, a JSON response example, and error codes (400, 409, 429).
3. **Given** a user scrolls to the Architecture section, **Then** they see production stats: sub-ms CDN redirect latency, 6-char Base62 slug generation (62⁶ = 56.8B namespace), collision safety, and 99.99% uptime SLA.
4. **Given** a user views the rate limits table, **Then** they see tiered limits for Free (100/min create, 1000/min redirect), Pro, and Enterprise.

---

### User Story 8 - Dark Terminal UI Aesthetic (Priority: P3)

As a user, I want the snip.ly interface to have a sleek dark terminal aesthetic with monospace fonts, neon green accents, CRT scanline effects, and a blinking cursor logo so the app feels modern and developer-focused.

**Why this priority**: Visual polish differentiates the product but doesn't affect functionality.

**Independent Test**: Load the app at the root URL and verify:
	- Dark theme: background #06080d, JetBrains Mono font, green accent #00ff9f
	- CRT scanline overlay: CSS repeating-linear-gradient, opacity 0.08, line spacing 2px, no animation
	- Blinking cursor: CSS animation, 1s blink interval, visible/invisible states
	- All visual effects are testable via DOM/CSS inspection

**Acceptance Scenarios**:

1. **Given** the user navigates to the root URL, **Then** the app loads a single-page frontend with dark background (#06080d), JetBrains Mono font, and a `$ snip.ly_` logo with a blinking cursor (CSS animation, 1s interval).
2. **Given** the page is loaded, **Then** a CRT scanline effect overlays the viewport (CSS: repeating-linear-gradient, opacity 0.08, 2px spacing, no animation).
3. **Given** any user interaction (shorten, copy, delete), **Then** toast notifications appear with success (green border) or error (red border) styling, auto-dismiss after 3s, max 2 concurrent toasts.
4. **Given** a mobile viewport, **Then** the layout adapts responsively with stacked inputs, hidden status indicator, and appropriately sized typography (font size ≥ 16px, line height ≥ 1.4, breakpoints at 600px and 900px).

---

### Edge Cases
- What happens if a custom alias matches a reserved route (e.g., 'health', 'api', 'api-docs')? → System rejects with HTTP 400; reserved paths are validated and listed in FR-XXX.
- What happens if a short URL contains a fragment, query string, or encoded characters? → Redirect preserves all original URL components; no modification or loss.
- What happens if the user opens My Links tab and data is still loading? → Show skeleton/loading state until data is fetched.
- What happens if the user triggers the 900ms simulated delay and then navigates away or submits again? → Only the latest request is processed; prior pending toasts/requests are cancelled.

- What happens when the generated short code collides with an existing one? → System retries with a new code (up to 3 attempts) before returning HTTP 500 (see FR-008).
- What happens when the database is unavailable? → Redirect attempts return HTTP 503 with a retry-friendly message; creation returns HTTP 503. Health check returns degraded status.
- What happens when a URL is extremely long (> 10,000 chars)? → System rejects with HTTP 400 and a max-length error.
- What happens with concurrent requests for the same custom code? → Only one succeeds (HTTP 201); the other gets HTTP 409 (database-level uniqueness constraint).
- What happens when rate limit is exceeded? → HTTP 429 with `Retry-After` header.
- What happens when analytics recording fails during redirect? → Redirect still succeeds (graceful degradation); the analytics failure is logged but does not block the user. Analytics are recorded synchronously; eventual consistency is not applicable.
- What happens when JavaScript is disabled? → The API still functions as a standalone REST service; the SPA frontend requires JavaScript.
- What happens when the user deletes a link? → Soft-delete (deactivation); existing short URLs return HTTP 410 Gone, preserving audit trail.


## Requirements *(mandatory)*

### Functional Requirements
**FR-001**: System MUST reject custom aliases that match reserved paths: 'health', 'api', 'api-docs', 'urls', 'static', 'swagger', 'favicon.ico'.
**FR-002**: System MUST prevent open-redirects by only redirecting to URLs stored in the database; arbitrary redirect targets are never allowed.
**FR-003**: SPA frontend MUST set a Content Security Policy (CSP) via helmet with directives: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'.
**FR-004**: System MUST not impose a hard limit on total URLs/clicks, but must document that SQLite file may grow unbounded; recommend monitoring file size in production.
**FR-005**: All constraint validation (custom code, URL format, reserved words, length) MUST be performed consistently in both API and frontend, using a single validation module. Duplicate or conflicting validation logic is not allowed. All validation errors MUST use the explicit error response schema (see FR-007).
**FR-006**: System MUST return proper HTTP status codes (201, 204, 301, 400, 404, 409, 410, 429, 500, 503). HTTP 500 is only returned for collision exhaustion (see Edge Cases).
**FR-007**: All API error responses MUST use the following explicit schema:

```json
{
  "error": {
    "code": "<error_code>",
    "message": "<human_readable_message>",
    "requestId": "<uuid>"
  }
}
```
Where `code` is a short string (e.g., 'not_found', 'invalid_url', 'rate_limited'), `message` is user-friendly, and `requestId` is always present for traceability. All error cases (validation, not found, conflict, rate limit, server error) MUST use this schema.

**FR-008**: All references to 'route' MUST use the term 'short URL' or 'short code' for clarity and consistency across all documentation, code, and UI. The term 'route' is reserved for internal Express routing only.

**FR-009**: Geocoding fallback and caching logic MUST be defined and implemented to ensure analytics remain robust if primary geocoding fails. If the primary geocoding service is unavailable or returns an error, the system MUST attempt a secondary provider and/or use cached results from the last successful lookup. All fallback/caching logic MUST be covered by tests and documented in the implementation plan.

**FR-010**: Audit log compliance MUST be specified: all create, delete, and redirect actions are logged with timestamp, user agent, and IP (if available), and logs are retained for 90 days minimum. Audit log implementation MUST be verifiable by test and documented in the plan and tasks.


### Non-Functional Requirements
**NFR-001**: Redirect latency p99 MUST be < 50ms under 1,000 concurrent requests. This MUST be measured in integration tests and reported in CI.
**NFR-002**: URL creation p95 MUST be < 200ms. This MUST be measured and reported in CI.
**NFR-003**: SPA frontend must load and become interactive in < 1.5s on a 3G connection (Lighthouse or WebPageTest).
**NFR-004**: The system must support 1,000 concurrent redirects with zero 5xx errors (integration test required).
**NFR-005**: UI must pass an independent usability test: all primary actions (shorten, copy, delete, view analytics) are discoverable within 2 clicks and have visible feedback (toast or modal) within 500ms. Usability test results MUST be documented.

---


### Key Entities


## Assumptions


## Success Criteria *(mandatory)*


### Measurable Outcomes

**SC-003**: System supports 1,000 concurrent redirect requests with zero 5xx errors, all returning HTTP 301 and correct Location header.
**SC-010**: Analytics modal and stats load within 500ms of clicking 📊 (API + render + animation).

