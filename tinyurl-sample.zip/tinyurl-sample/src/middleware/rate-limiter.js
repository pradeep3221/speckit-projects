import rateLimit from 'express-rate-limit';
import config from '../config.js';

/**
 * Rate limiter for URL creation endpoints.
 * 100 requests per minute per IP.
 */
export const createLimiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.maxCreate,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests. Please try again later.' },
});

/**
 * Rate limiter for redirect endpoints.
 * Higher limit since redirects are the primary use case.
 */
export const redirectLimiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.maxRedirect,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests. Please try again later.' },
});
