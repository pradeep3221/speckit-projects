import config from '../config.js';

/**
 * Validate a URL string.
 * @param {string} url - The URL to validate
 * @returns {{ valid: boolean, error?: string }}
 */
export function validateUrl(url) {
  if (!url || typeof url !== 'string') {
    return { valid: false, error: 'URL is required and must be a string' };
  }

  if (url.length > config.maxUrlLength) {
    return { valid: false, error: `URL exceeds maximum length of ${config.maxUrlLength} characters` };
  }

  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return { valid: false, error: 'Invalid URL format' };
  }

  const allowedSchemes = ['http:', 'https:'];
  if (!allowedSchemes.includes(parsed.protocol)) {
    return { valid: false, error: 'Only http and https URLs are allowed' };
  }

  return { valid: true };
}

/**
 * Validate a custom short code.
 * @param {string} code - The custom code to validate
 * @returns {{ valid: boolean, error?: string }}
 */
export function validateCustomCode(code) {
  if (!code || typeof code !== 'string') {
    return { valid: false, error: 'Custom code must be a non-empty string' };
  }

  if (code.length < 3 || code.length > 30) {
    return { valid: false, error: 'Custom code must be between 3 and 30 characters' };
  }

  if (!/^[a-zA-Z0-9-]+$/.test(code)) {
    return { valid: false, error: 'Custom code can only contain letters, numbers, and hyphens' };
  }

  return { valid: true };
}

/**
 * Express middleware for URL validation on request body.
 */
export function validateUrlMiddleware(req, res, next) {
  const { url } = req.body;
  const result = validateUrl(url);

  if (!result.valid) {
    return res.status(400).json({ error: result.error });
  }

  next();
}
