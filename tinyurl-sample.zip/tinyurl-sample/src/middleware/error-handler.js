import logger from '../logger.js';

/**
 * Centralized error handler middleware for Express.
 * Must be registered AFTER all routes.
 */
export function errorHandler(err, req, res, _next) {
  const status = err.status || err.statusCode || 500;
  const message = err.message || 'Internal Server Error';

  // Log with structured context
  const logPayload = {
    err,
    requestId: req.id,
    method: req.method,
    url: req.originalUrl,
    status,
  };

  if (status >= 500) {
    logger.error(logPayload, `Server error: ${message}`);
  } else {
    logger.warn(logPayload, `Client error: ${message}`);
  }

  res.status(status).json({
    error: status >= 500 ? 'Internal Server Error' : message,
    ...(status < 500 && err.details ? { details: err.details } : {}),
    requestId: req.id,
  });
}

/**
 * 404 handler for routes that don't match any defined endpoint.
 */
export function notFoundHandler(req, res, _next) {
  res.status(404).json({
    error: 'Not Found',
    message: `Cannot ${req.method} ${req.originalUrl}`,
    requestId: req.id,
  });
}

/**
 * Create an HTTP error with a status code.
 */
export function createHttpError(status, message, details) {
  const error = new Error(message);
  error.status = status;
  if (details) error.details = details;
  return error;
}
