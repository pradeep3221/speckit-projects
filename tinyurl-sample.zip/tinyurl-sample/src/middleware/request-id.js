import { randomUUID } from 'crypto';

const REQUEST_ID_HEADER = 'x-request-id';

/**
 * Middleware that ensures every request has a unique ID.
 * Uses the incoming X-Request-Id header if present (from a load balancer/gateway),
 * otherwise generates a new UUID v4.
 */
export function requestId(req, res, next) {
  const id = req.get(REQUEST_ID_HEADER) || randomUUID();
  req.id = id;
  res.set(REQUEST_ID_HEADER, id);
  next();
}
