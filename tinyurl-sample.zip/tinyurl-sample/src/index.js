import app from './app.js';
import { initDatabase, closeDatabase } from './db/database.js';
import config from './config.js';
import logger from './logger.js';

async function start() {
  await initDatabase();
  logger.info('Database initialized');

  const server = app.listen(config.port, () => {
    logger.info(
      { port: config.port, env: config.nodeEnv, baseUrl: config.baseUrl },
      `ProjectTinyURL running at ${config.baseUrl}`
    );
  });

  // Keep-alive and headers timeout (important behind load balancers)
  server.keepAliveTimeout = 65_000; // slightly higher than typical ALB 60s
  server.headersTimeout = 66_000;

  // ── Graceful shutdown ────────────────────────────────────────────
  let isShuttingDown = false;

  async function shutdown(signal) {
    if (isShuttingDown) return;
    isShuttingDown = true;
    logger.info({ signal }, 'Shutdown signal received — draining connections');

    // Force-exit safety net
    const forceTimer = setTimeout(() => {
      logger.error('Graceful shutdown timed out — forcing exit');
      process.exit(1);
    }, config.shutdown.timeoutMs);
    forceTimer.unref();

    server.close(() => {
      logger.info('HTTP server closed');
      closeDatabase();
      logger.info('Database closed');
      clearTimeout(forceTimer);
      process.exit(0);
    });
  }

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));

  // ── Process-level safety nets ────────────────────────────────────
  process.on('unhandledRejection', (reason, promise) => {
    logger.fatal({ err: reason, promise }, 'Unhandled promise rejection');
    shutdown('unhandledRejection');
  });

  process.on('uncaughtException', (err) => {
    logger.fatal({ err }, 'Uncaught exception');
    shutdown('uncaughtException');
  });
}

start().catch((err) => {
  logger.fatal({ err }, 'Failed to start server');
  process.exit(1);
});
