function requiredInProduction(name, fallback) {
  const value = process.env[name];
  if (!value && process.env.NODE_ENV === 'production' && fallback === undefined) {
    throw new Error(`Environment variable ${name} is required in production`);
  }
  return value || fallback;
}

const nodeEnv = process.env.NODE_ENV || 'development';

const config = {
  nodeEnv,
  isProduction: nodeEnv === 'production',
  isTest: nodeEnv === 'test',

  port: parseInt(process.env.PORT || '3000', 10),
  dbPath: process.env.DB_PATH || 'tinyurl.db',
  baseUrl: requiredInProduction('BASE_URL', 'http://localhost:3000'),
  shortCodeLength: parseInt(process.env.SHORT_CODE_LENGTH || '6', 10),

  logLevel: process.env.LOG_LEVEL || (nodeEnv === 'production' ? 'info' : 'debug'),

  // Behind a reverse proxy (nginx, ALB, etc.)
  trustProxy: process.env.TRUST_PROXY === 'true' || false,

  cors: {
    origin: process.env.CORS_ORIGIN || '*',
  },

  rateLimit: {
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || String(60 * 1000), 10),
    maxCreate: parseInt(process.env.RATE_LIMIT_MAX_CREATE || '100', 10),
    maxRedirect: parseInt(process.env.RATE_LIMIT_MAX_REDIRECT || '1000', 10),
  },

  maxUrlLength: 10000,

  shutdown: {
    timeoutMs: parseInt(process.env.SHUTDOWN_TIMEOUT_MS || '10000', 10),
  },
};

// Validate numeric fields
for (const [key, val] of Object.entries({
  port: config.port,
  shortCodeLength: config.shortCodeLength,
})) {
  if (Number.isNaN(val) || val <= 0) {
    throw new Error(`Invalid configuration: ${key} must be a positive integer`);
  }
}

export default config;
