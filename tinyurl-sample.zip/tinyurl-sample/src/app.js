import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import pinoHttp from 'pino-http';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import swaggerUi from 'swagger-ui-express';
import swaggerDocument from './swagger.js';
import urlsRouter from './routes/urls.js';
import redirectRouter from './routes/redirect.js';
import { redirectLimiter } from './middleware/rate-limiter.js';
import healthRouter from './routes/health.js';
import { errorHandler, notFoundHandler } from './middleware/error-handler.js';
import { createLimiter } from './middleware/rate-limiter.js';
import { requestId } from './middleware/request-id.js';
import config from './config.js';
import logger from './logger.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();

// Trust reverse proxy headers (X-Forwarded-For, etc.)
if (config.trustProxy) {
  app.set('trust proxy', 1);
}

// Request ID — must be first so all downstream middleware/logs have it
app.use(requestId);

// Structured HTTP request logging
app.use(
  pinoHttp({
    logger,
    genReqId: (req) => req.id,
    // Don't log health check requests to reduce noise
    autoLogging: {
      ignore: (req) => req.url === '/health',
    },
  })
);

// Security headers
app.use(helmet());

// CORS
app.use(cors(config.cors));

// Body parsing with size limit
app.use(express.json({ limit: '1mb' }));

// Swagger API docs (disable in production if desired)
if (!config.isProduction) {
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
}

// Routes
app.use('/health', healthRouter);
app.use('/api/v1/urls', createLimiter, urlsRouter);
app.use('/:shortCode', redirectLimiter, redirectRouter);

// Serve the frontend SPA from public/
app.use(express.static(join(__dirname, '..', 'public')));

// Redirect must be LAST to avoid catching /api/* and /health routes
app.use('/', redirectRouter);

// 404 handler for unmatched routes
app.use(notFoundHandler);

// Centralized error handling
app.use(errorHandler);

export default app;
