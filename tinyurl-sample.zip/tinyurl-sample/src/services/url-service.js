import { getDatabase, saveDatabase } from '../db/database.js';
import { generateShortCode } from '../utils/code-generator.js';
import { validateUrl, validateCustomCode } from '../middleware/validator.js';
import config from '../config.js';

/**
 * Check if a short code already exists in the database.
 */
function codeExists(code) {
  const db = getDatabase();
  const result = db.exec('SELECT 1 FROM urls WHERE short_code = ?', [code]);
  return result.length > 0 && result[0].values.length > 0;
}

/**
 * Create a new shortened URL.
 * @param {string} originalUrl - The URL to shorten
 * @param {string} [customCode] - Optional custom short code
 * @returns {Promise<object>} The created URL record
 */
export async function createUrl(originalUrl, customCode) {
  const db = getDatabase();

  // Validate URL
  const urlValidation = validateUrl(originalUrl);
  if (!urlValidation.valid) {
    const error = new Error(urlValidation.error);
    error.status = 400;
    throw error;
  }

  let shortCode;

  if (customCode) {
    // Validate custom code format
    const codeValidation = validateCustomCode(customCode);
    if (!codeValidation.valid) {
      const error = new Error(codeValidation.error);
      error.status = 400;
      throw error;
    }

    // Check if custom code is already taken
    if (codeExists(customCode)) {
      const error = new Error('Short code is already in use');
      error.status = 409;
      throw error;
    }

    shortCode = customCode;
  } else {
    // Generate a unique code
    shortCode = await generateShortCode((code) => codeExists(code));
  }

  db.run(
    'INSERT INTO urls (short_code, original_url) VALUES (?, ?)',
    [shortCode, originalUrl]
  );
  saveDatabase();

  return {
    shortCode,
    shortUrl: `${config.baseUrl}/${shortCode}`,
    originalUrl,
    createdAt: new Date().toISOString(),
  };
}

/**
 * Get a URL record by short code.
 * @param {string} shortCode
 * @returns {object|null}
 */
export function getByCode(shortCode) {
  const db = getDatabase();
  const result = db.exec(
    'SELECT short_code, original_url, is_active, click_count, created_at FROM urls WHERE short_code = ?',
    [shortCode]
  );

  if (result.length === 0 || result[0].values.length === 0) {
    return null;
  }

  const row = result[0].values[0];
  return {
    shortCode: row[0],
    originalUrl: row[1],
    isActive: row[2] === 1,
    clickCount: row[3],
    createdAt: row[4],
  };
}

/**
 * List URLs with pagination.
 * @param {number} page - Page number (1-based)
 * @param {number} limit - Items per page
 * @returns {{ urls: object[], total: number, page: number, limit: number }}
 */
export function listUrls(page = 1, limit = 20) {
  const db = getDatabase();
  limit = Math.min(Math.max(limit, 1), 100);
  page = Math.max(page, 1);
  const offset = (page - 1) * limit;

  const countResult = db.exec('SELECT COUNT(*) FROM urls');
  const total = countResult[0]?.values[0]?.[0] || 0;

  const result = db.exec(
    'SELECT short_code, original_url, is_active, click_count, created_at FROM urls ORDER BY created_at DESC LIMIT ? OFFSET ?',
    [limit, offset]
  );

  const urls = (result[0]?.values || []).map((row) => ({
    shortCode: row[0],
    shortUrl: `${config.baseUrl}/${row[0]}`,
    originalUrl: row[1],
    isActive: row[2] === 1,
    clickCount: row[3],
    createdAt: row[4],
  }));

  return { urls, total, page, limit };
}

/**
 * Soft-delete a URL by short code (deactivates it).
 * Per constitution: "URL mappings are immutable once created; soft deletes for audit trail"
 * @param {string} shortCode
 * @returns {boolean} true if found and deactivated, false if not found
 */
export function deleteUrl(shortCode) {
  const db = getDatabase();
  const url = getByCode(shortCode);
  if (!url) return false;

  db.run('UPDATE urls SET is_active = 0 WHERE short_code = ?', [shortCode]);
  saveDatabase();
  return true;
}
