import { getDatabase, saveDatabase } from '../db/database.js';

/**
 * Record a click event for a short code.
 * Inserts into clicks table and increments the denormalized counter.
 * @param {string} shortCode
 * @param {string|null} referrer
 * @param {string|null} userAgent
 */
export function recordClick(shortCode, referrer, userAgent) {
  const db = getDatabase();

  db.run(
    'INSERT INTO clicks (short_code, referrer, user_agent) VALUES (?, ?, ?)',
    [shortCode, referrer || null, userAgent || null]
  );

  db.run(
    'UPDATE urls SET click_count = click_count + 1 WHERE short_code = ?',
    [shortCode]
  );

  saveDatabase();
}

/**
 * Get click analytics for a short code.
 * @param {string} shortCode
 * @returns {{ totalClicks: number, clicks: object[] }}
 */
export function getStats(shortCode) {
  const db = getDatabase();

  // Get total clicks from the denormalized counter
  const urlResult = db.exec(
    'SELECT click_count FROM urls WHERE short_code = ?',
    [shortCode]
  );

  if (urlResult.length === 0 || urlResult[0].values.length === 0) {
    return null;
  }

  const totalClicks = urlResult[0].values[0][0];

  // Get individual click records
  const clicksResult = db.exec(
    'SELECT referrer, user_agent, clicked_at FROM clicks WHERE short_code = ? ORDER BY clicked_at DESC',
    [shortCode]
  );

  const clicks = (clicksResult[0]?.values || []).map((row) => ({
    referrer: row[0],
    userAgent: row[1],
    timestamp: row[2],
  }));

  return { totalClicks, clicks };
}
