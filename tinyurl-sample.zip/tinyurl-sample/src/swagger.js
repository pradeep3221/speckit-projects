const swaggerDocument = {
  openapi: '3.0.3',
  info: {
    title: 'TinyURL API',
    description: 'A URL shortening service with click analytics',
    version: '1.0.0',
    license: { name: 'MIT' },
  },
  servers: [
    { url: 'http://localhost:3000', description: 'Local development' },
  ],
  tags: [
    { name: 'URLs', description: 'URL shortening operations' },
    { name: 'Redirect', description: 'Short URL redirection' },
    { name: 'Health', description: 'Service health check' },
  ],
  paths: {
    '/api/v1/urls': {
      post: {
        tags: ['URLs'],
        summary: 'Create a short URL',
        description: 'Shorten a long URL. Optionally provide a custom short code.',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['url'],
                properties: {
                  url: {
                    type: 'string',
                    format: 'uri',
                    example: 'https://example.com/very/long/path',
                    description: 'The original URL to shorten',
                  },
                  customCode: {
                    type: 'string',
                    minLength: 3,
                    maxLength: 30,
                    pattern: '^[a-zA-Z0-9-]+$',
                    example: 'my-link',
                    description: 'Optional custom short code (alphanumeric, hyphens only)',
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description: 'Short URL created successfully',
            content: {
              'application/json': {
                schema: { $ref: '#/components/schemas/CreatedUrl' },
              },
            },
          },
          400: {
            description: 'Invalid URL or custom code format',
            content: {
              'application/json': {
                schema: { $ref: '#/components/schemas/Error' },
              },
            },
          },
          409: {
            description: 'Custom short code already in use',
            content: {
              'application/json': {
                schema: { $ref: '#/components/schemas/Error' },
              },
            },
          },
          429: {
            description: 'Rate limit exceeded',
          },
        },
      },
      get: {
        tags: ['URLs'],
        summary: 'List all URLs (paginated)',
        parameters: [
          {
            name: 'page',
            in: 'query',
            schema: { type: 'integer', default: 1, minimum: 1 },
            description: 'Page number',
          },
          {
            name: 'limit',
            in: 'query',
            schema: { type: 'integer', default: 20, minimum: 1, maximum: 100 },
            description: 'Items per page',
          },
        ],
        responses: {
          200: {
            description: 'Paginated list of URLs',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    urls: {
                      type: 'array',
                      items: { $ref: '#/components/schemas/UrlRecord' },
                    },
                    total: { type: 'integer', example: 42 },
                    page: { type: 'integer', example: 1 },
                    limit: { type: 'integer', example: 20 },
                  },
                },
              },
            },
          },
        },
      },
    },
    '/api/v1/urls/{code}/stats': {
      get: {
        tags: ['URLs'],
        summary: 'Get click analytics for a short URL',
        parameters: [
          {
            name: 'code',
            in: 'path',
            required: true,
            schema: { type: 'string' },
            description: 'The short code',
          },
        ],
        responses: {
          200: {
            description: 'Click analytics',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    shortCode: { type: 'string', example: 'abc1234' },
                    originalUrl: { type: 'string', example: 'https://example.com' },
                    totalClicks: { type: 'integer', example: 15 },
                    clicks: {
                      type: 'array',
                      items: { $ref: '#/components/schemas/ClickRecord' },
                    },
                  },
                },
              },
            },
          },
          404: {
            description: 'Short URL not found',
            content: {
              'application/json': {
                schema: { $ref: '#/components/schemas/Error' },
              },
            },
          },
        },
      },
    },
    '/api/v1/urls/{code}': {
      delete: {
        tags: ['URLs'],
        summary: 'Deactivate (soft-delete) a short URL',
        description: 'Soft-deletes the URL mapping. The short code will return 410 Gone after deletion.',
        parameters: [
          {
            name: 'code',
            in: 'path',
            required: true,
            schema: { type: 'string' },
            description: 'The short code to deactivate',
          },
        ],
        responses: {
          204: {
            description: 'Short URL deactivated successfully',
          },
          404: {
            description: 'Short URL not found',
            content: {
              'application/json': {
                schema: { $ref: '#/components/schemas/Error' },
              },
            },
          },
        },
      },
    },
    '/{shortCode}': {
      get: {
        tags: ['Redirect'],
        summary: 'Redirect to the original URL',
        parameters: [
          {
            name: 'shortCode',
            in: 'path',
            required: true,
            schema: { type: 'string' },
            description: 'The short code to resolve',
          },
        ],
        responses: {
          301: {
            description: 'Redirect to the original URL',
            headers: {
              Location: {
                schema: { type: 'string' },
                description: 'The original URL',
              },
            },
          },
          404: {
            description: 'Short URL not found',
            content: {
              'application/json': {
                schema: { $ref: '#/components/schemas/Error' },
              },
            },
          },
          410: {
            description: 'Short URL has been deactivated',
            content: {
              'application/json': {
                schema: { $ref: '#/components/schemas/Error' },
              },
            },
          },
        },
      },
    },
    '/health': {
      get: {
        tags: ['Health'],
        summary: 'Service health check',
        responses: {
          200: {
            description: 'Service is healthy',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    status: { type: 'string', example: 'ok' },
                    timestamp: { type: 'string', format: 'date-time' },
                  },
                },
              },
            },
          },
          503: {
            description: 'Service is unhealthy',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    status: { type: 'string', example: 'error' },
                    message: { type: 'string' },
                    timestamp: { type: 'string', format: 'date-time' },
                  },
                },
              },
            },
          },
        },
      },
    },
  },
  components: {
    schemas: {
      CreatedUrl: {
        type: 'object',
        properties: {
          shortCode: { type: 'string', example: 'abc1234' },
          shortUrl: { type: 'string', example: 'http://localhost:3000/abc1234' },
          originalUrl: { type: 'string', example: 'https://example.com/very/long/path' },
          createdAt: { type: 'string', format: 'date-time' },
        },
      },
      UrlRecord: {
        type: 'object',
        properties: {
          shortCode: { type: 'string', example: 'abc1234' },
          shortUrl: { type: 'string', example: 'http://localhost:3000/abc1234' },
          originalUrl: { type: 'string', example: 'https://example.com' },
          isActive: { type: 'boolean', example: true },
          clickCount: { type: 'integer', example: 15 },
          createdAt: { type: 'string', format: 'date-time' },
        },
      },
      ClickRecord: {
        type: 'object',
        properties: {
          referrer: { type: 'string', nullable: true, example: 'https://google.com' },
          userAgent: { type: 'string', nullable: true, example: 'Mozilla/5.0...' },
          timestamp: { type: 'string', format: 'date-time' },
        },
      },
      Error: {
        type: 'object',
        properties: {
          error: { type: 'string', example: 'Short URL not found' },
        },
      },
    },
  },
};

export default swaggerDocument;
