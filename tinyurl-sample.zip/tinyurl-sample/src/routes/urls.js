import { Router } from 'express';
import { createUrl, listUrls, deleteUrl } from '../services/url-service.js';
import { getStats } from '../services/analytics-service.js';
import { getByCode } from '../services/url-service.js';
import { validateUrlMiddleware } from '../middleware/validator.js';

const router = Router();

/**
 * POST /api/v1/urls - Create a short URL
 */
router.post('/', validateUrlMiddleware, async (req, res, next) => {
  try {
    const { url, customCode } = req.body;
    const result = await createUrl(url, customCode);
    res.status(201).json(result);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/v1/urls - List all URLs (paginated)
 */
router.get('/', (req, res) => {
  const page = parseInt(req.query.page || '1', 10);
  const limit = parseInt(req.query.limit || '20', 10);
  const result = listUrls(page, limit);
  res.json(result);
});

/**
 * GET /api/v1/urls/:code/stats - Get click analytics
 */
router.get('/:code/stats', (req, res) => {
  const { code } = req.params;
  const urlRecord = getByCode(code);

  if (!urlRecord) {
    return res.status(404).json({ error: 'Short URL not found' });
  }

  const stats = getStats(code);
  res.json({
    shortCode: code,
    originalUrl: urlRecord.originalUrl,
    totalClicks: stats.totalClicks,
    clicks: stats.clicks,
  });
});

/**
 * DELETE /api/v1/urls/:code - Soft-delete (deactivate) a short URL
 */
router.delete('/:code', (req, res) => {
  const { code } = req.params;
  const deleted = deleteUrl(code);

  if (!deleted) {
    return res.status(404).json({ error: 'Short URL not found' });
  }

  res.status(204).end();
});

export default router;
