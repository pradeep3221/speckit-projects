import { Router } from 'express';
import { getByCode } from '../services/url-service.js';
import { recordClick } from '../services/analytics-service.js';
import logger from '../logger.js';

const router = Router();

/**
 * GET /:shortCode - Redirect to original URL
 */
router.get('/:shortCode', (req, res) => {
  const { shortCode } = req.params;
  const urlRecord = getByCode(shortCode);

  if (!urlRecord) {
    return res.status(404).json({ error: 'Short URL not found' });
  }

  if (!urlRecord.isActive) {
    return res.status(410).json({ error: 'This short URL has been deactivated' });
  }

  // Record click analytics — gracefully degrade if it fails (constitution §II)
  try {
    const referrer = req.get('referer') || req.get('referrer') || null;
    const userAgent = req.get('user-agent') || null;
    recordClick(shortCode, referrer, userAgent);
  } catch (err) {
    logger.error({ err, shortCode, requestId: req.id }, 'Failed to record click analytics');
  }

  // Redirect
  res.set('Cache-Control', 'public, max-age=86400');
  res.redirect(301, urlRecord.originalUrl);
});

export default router;
