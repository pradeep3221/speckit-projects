import { Router } from 'express';
import { getDatabase } from '../db/database.js';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

let version = 'unknown';
try {
  const pkg = JSON.parse(
    readFileSync(join(__dirname, '..', '..', 'package.json'), 'utf-8')
  );
  version = pkg.version;
} catch {
  // ignore — non-critical
}

const router = Router();

/**
 * GET /health - Health check endpoint
 * Returns service status, uptime, version, and memory usage.
 */
router.get('/', (req, res) => {
  const checks = { database: 'ok' };

  try {
    const db = getDatabase();
    db.exec('SELECT 1');
  } catch {
    checks.database = 'error';
  }

  const isHealthy = Object.values(checks).every((v) => v === 'ok');
  const mem = process.memoryUsage();

  res.status(isHealthy ? 200 : 503).json({
    status: isHealthy ? 'ok' : 'degraded',
    version,
    uptime: Math.floor(process.uptime()),
    timestamp: new Date().toISOString(),
    checks,
    memory: {
      rss: Math.round(mem.rss / 1024 / 1024),
      heapUsed: Math.round(mem.heapUsed / 1024 / 1024),
      heapTotal: Math.round(mem.heapTotal / 1024 / 1024),
    },
  });
});

export default router;
