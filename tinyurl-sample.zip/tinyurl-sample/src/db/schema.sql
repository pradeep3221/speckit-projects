-- Enable WAL mode for better concurrent read performance
PRAGMA journal_mode=WAL;

-- URL mappings
CREATE TABLE IF NOT EXISTS urls (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    short_code  TEXT    UNIQUE NOT NULL,
    original_url TEXT   NOT NULL,
    is_active   INTEGER DEFAULT 1,
    click_count INTEGER DEFAULT 0,
    created_at  TEXT    DEFAULT (datetime('now'))
);

-- Click analytics events
CREATE TABLE IF NOT EXISTS clicks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    short_code  TEXT    NOT NULL,
    referrer    TEXT,
    user_agent  TEXT,
    clicked_at  TEXT    DEFAULT (datetime('now')),
    FOREIGN KEY (short_code) REFERENCES urls(short_code) ON DELETE CASCADE
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_urls_short_code   ON urls(short_code);
CREATE INDEX IF NOT EXISTS idx_clicks_short_code ON clicks(short_code);
CREATE INDEX IF NOT EXISTS idx_clicks_clicked_at ON clicks(clicked_at);
