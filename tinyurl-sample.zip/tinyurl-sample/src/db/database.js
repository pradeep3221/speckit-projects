import initSqlJs from 'sql.js';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import config from '../config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

let db = null;

const schemaSQL = readFileSync(join(__dirname, 'schema.sql'), 'utf-8');

/**
 * Initialize the SQLite database.
 * Loads from file if it exists, otherwise creates a new one.
 */
export async function initDatabase(dbPath = config.dbPath) {
  const SQL = await initSqlJs();

  if (dbPath === ':memory:') {
    db = new SQL.Database();
  } else if (existsSync(dbPath)) {
    const buffer = readFileSync(dbPath);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
  }

  // Run schema (IF NOT EXISTS ensures idempotency)
  db.run(schemaSQL);

  return db;
}

/**
 * Get the current database instance.
 */
export function getDatabase() {
  if (!db) {
    throw new Error('Database not initialized. Call initDatabase() first.');
  }
  return db;
}

/**
 * Persist database to disk (call periodically or on changes).
 */
export function saveDatabase(dbPath = config.dbPath) {
  if (!db || dbPath === ':memory:') return;
  const data = db.export();
  const buffer = Buffer.from(data);
  writeFileSync(dbPath, buffer);
}

/**
 * Close the database and save to disk.
 */
export function closeDatabase(dbPath = config.dbPath) {
  if (!db) return;
  saveDatabase(dbPath);
  db.close();
  db = null;
}

/**
 * Set the database instance directly (used in tests).
 */
export function setDatabase(newDb) {
  db = newDb;
}
