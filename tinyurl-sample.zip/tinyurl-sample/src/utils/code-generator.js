import { customAlphabet } from 'nanoid';
import config from '../config.js';

const ALPHABET = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

const generate = customAlphabet(ALPHABET, config.shortCodeLength);

/**
 * Generate a unique short code.
 * @param {function} existsCheck - async fn(code) => boolean, checks if code already exists
 * @param {number} maxRetries - maximum retry attempts on collision (default 3)
 * @returns {Promise<string>} unique short code
 */
export async function generateShortCode(existsCheck, maxRetries = 3) {
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    const code = generate();
    if (!existsCheck || !(await existsCheck(code))) {
      return code;
    }
  }
  throw new Error('Failed to generate unique short code after maximum retries');
}
