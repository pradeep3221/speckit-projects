import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import request from 'supertest';
import app from '../../src/app.js';
import { createTestDb, closeTestDb } from '../helpers/test-db.js';

describe('GET /health', () => {
  let db;

  beforeEach(async () => {
    db = await createTestDb();
  });

  afterEach(() => {
    closeTestDb(db);
  });

  it('returns 200 with ok status', async () => {
    const res = await request(app)
      .get('/health')
      .expect(200);

    expect(res.body.status).toBe('ok');
    expect(res.body.timestamp).toBeDefined();
  });
});
