import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import request from 'supertest';
import app from '../../src/app.js';
import { createTestDb, closeTestDb } from '../helpers/test-db.js';

describe('GET /api/v1/urls/:code/stats', () => {
  let db;

  beforeEach(async () => {
    db = await createTestDb();
  });

  afterEach(() => {
    closeTestDb(db);
  });

  it('returns stats with zero clicks for new URL', async () => {
    const createRes = await request(app)
      .post('/api/v1/urls')
      .send({ url: 'https://example.com' });

    const { shortCode } = createRes.body;

    const res = await request(app)
      .get(`/api/v1/urls/${shortCode}/stats`)
      .expect(200);

    expect(res.body.shortCode).toBe(shortCode);
    expect(res.body.totalClicks).toBe(0);
    expect(res.body.clicks).toHaveLength(0);
  });

  it('increments click count after redirects', async () => {
    const createRes = await request(app)
      .post('/api/v1/urls')
      .send({ url: 'https://example.com' });

    const { shortCode } = createRes.body;

    // Simulate 3 redirects
    for (let i = 0; i < 3; i++) {
      await request(app)
        .get(`/${shortCode}`)
        .redirects(0);
    }

    const res = await request(app)
      .get(`/api/v1/urls/${shortCode}/stats`)
      .expect(200);

    expect(res.body.totalClicks).toBe(3);
    expect(res.body.clicks).toHaveLength(3);
  });

  it('captures referrer and user-agent in click data', async () => {
    const createRes = await request(app)
      .post('/api/v1/urls')
      .send({ url: 'https://example.com' });

    const { shortCode } = createRes.body;

    await request(app)
      .get(`/${shortCode}`)
      .set('Referer', 'https://twitter.com')
      .set('User-Agent', 'TestBot/1.0')
      .redirects(0);

    const res = await request(app)
      .get(`/api/v1/urls/${shortCode}/stats`)
      .expect(200);

    expect(res.body.clicks[0].referrer).toBe('https://twitter.com');
    expect(res.body.clicks[0].userAgent).toBe('TestBot/1.0');
  });

  it('returns 404 for non-existent short code stats', async () => {
    await request(app)
      .get('/api/v1/urls/nonexist/stats')
      .expect(404);
  });
});
