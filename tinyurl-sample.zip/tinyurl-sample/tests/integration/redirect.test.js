import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import request from 'supertest';
import app from '../../src/app.js';
import { createTestDb, closeTestDb } from '../helpers/test-db.js';

describe('GET /:shortCode (redirect)', () => {
  let db;

  beforeEach(async () => {
    db = await createTestDb();
  });

  afterEach(() => {
    closeTestDb(db);
  });

  it('returns 301 redirect for valid active short code', async () => {
    // Create a short URL
    const createRes = await request(app)
      .post('/api/v1/urls')
      .send({ url: 'https://example.com/destination' });

    const { shortCode } = createRes.body;

    const res = await request(app)
      .get(`/${shortCode}`)
      .redirects(0)
      .expect(301);

    expect(res.headers.location).toBe('https://example.com/destination');
  });

  it('returns 404 for non-existent short code', async () => {
    await request(app)
      .get('/nonexist')
      .expect(404);
  });

  it('returns 410 for deactivated short code', async () => {
    // Create a short URL
    const createRes = await request(app)
      .post('/api/v1/urls')
      .send({ url: 'https://example.com' });

    const { shortCode } = createRes.body;

    // Deactivate it directly in DB
    db.run('UPDATE urls SET is_active = 0 WHERE short_code = ?', [shortCode]);

    await request(app)
      .get(`/${shortCode}`)
      .expect(410);
  });

  it('sets Cache-Control header on redirect', async () => {
    const createRes = await request(app)
      .post('/api/v1/urls')
      .send({ url: 'https://example.com' });

    const res = await request(app)
      .get(`/${createRes.body.shortCode}`)
      .redirects(0)
      .expect(301);

    expect(res.headers['cache-control']).toContain('max-age=86400');
  });
});
