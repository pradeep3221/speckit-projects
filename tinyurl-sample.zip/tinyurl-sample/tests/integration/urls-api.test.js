import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import request from 'supertest';
import app from '../../src/app.js';
import { createTestDb, closeTestDb } from '../helpers/test-db.js';

describe('POST /api/v1/urls', () => {
  let db;

  beforeEach(async () => {
    db = await createTestDb();
  });

  afterEach(() => {
    closeTestDb(db);
  });

  it('returns 201 with short URL for valid input', async () => {
    const res = await request(app)
      .post('/api/v1/urls')
      .send({ url: 'https://example.com/long/path' })
      .expect(201);

    expect(res.body.shortCode).toHaveLength(6);
    expect(res.body.originalUrl).toBe('https://example.com/long/path');
    expect(res.body.shortUrl).toContain(res.body.shortCode);
    expect(res.body.createdAt).toBeDefined();
  });

  it('returns 400 for missing URL', async () => {
    const res = await request(app)
      .post('/api/v1/urls')
      .send({})
      .expect(400);

    expect(res.body.error).toBeDefined();
  });

  it('returns 400 for invalid URL format', async () => {
    const res = await request(app)
      .post('/api/v1/urls')
      .send({ url: 'not-a-url' })
      .expect(400);

    expect(res.body.error).toContain('Invalid URL');
  });

  it('returns 400 for non-http scheme', async () => {
    const res = await request(app)
      .post('/api/v1/urls')
      .send({ url: 'ftp://files.example.com/doc' })
      .expect(400);

    expect(res.body.error).toContain('http and https');
  });

  it('creates different codes for same URL submitted twice', async () => {
    const res1 = await request(app)
      .post('/api/v1/urls')
      .send({ url: 'https://example.com' })
      .expect(201);

    const res2 = await request(app)
      .post('/api/v1/urls')
      .send({ url: 'https://example.com' })
      .expect(201);

    expect(res1.body.shortCode).not.toBe(res2.body.shortCode);
  });

  it('accepts a custom short code', async () => {
    const res = await request(app)
      .post('/api/v1/urls')
      .send({ url: 'https://example.com', customCode: 'my-brand' })
      .expect(201);

    expect(res.body.shortCode).toBe('my-brand');
  });

  it('returns 409 when custom code is taken', async () => {
    await request(app)
      .post('/api/v1/urls')
      .send({ url: 'https://example.com', customCode: 'taken' })
      .expect(201);

    await request(app)
      .post('/api/v1/urls')
      .send({ url: 'https://other.com', customCode: 'taken' })
      .expect(409);
  });

  it('returns 400 for invalid custom code characters', async () => {
    await request(app)
      .post('/api/v1/urls')
      .send({ url: 'https://example.com', customCode: 'bad code!' })
      .expect(400);
  });
});

describe('GET /api/v1/urls', () => {
  let db;

  beforeEach(async () => {
    db = await createTestDb();
  });

  afterEach(() => {
    closeTestDb(db);
  });

  it('returns empty list when no URLs exist', async () => {
    const res = await request(app)
      .get('/api/v1/urls')
      .expect(200);

    expect(res.body.urls).toHaveLength(0);
    expect(res.body.total).toBe(0);
  });

  it('returns paginated URLs', async () => {
    // Create 3 URLs
    for (let i = 0; i < 3; i++) {
      await request(app)
        .post('/api/v1/urls')
        .send({ url: `https://example.com/${i}` });
    }

    const res = await request(app)
      .get('/api/v1/urls?page=1&limit=2')
      .expect(200);

    expect(res.body.urls).toHaveLength(2);
    expect(res.body.total).toBe(3);
    expect(res.body.page).toBe(1);
    expect(res.body.limit).toBe(2);
  });
});
