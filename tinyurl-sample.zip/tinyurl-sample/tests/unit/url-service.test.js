import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { createUrl, getByCode, listUrls } from '../../src/services/url-service.js';
import { createTestDb, closeTestDb } from '../helpers/test-db.js';

describe('url-service', () => {
  let db;

  beforeEach(async () => {
    db = await createTestDb();
  });

  afterEach(() => {
    closeTestDb(db);
  });

  describe('createUrl', () => {
    it('creates a URL and returns a record with short code', async () => {
      const result = await createUrl('https://example.com');
      expect(result.shortCode).toHaveLength(6);
      expect(result.originalUrl).toBe('https://example.com');
      expect(result.shortUrl).toContain(result.shortCode);
      expect(result.createdAt).toBeDefined();
    });

    it('creates unique codes for duplicate URL submissions', async () => {
      const r1 = await createUrl('https://example.com');
      const r2 = await createUrl('https://example.com');
      expect(r1.shortCode).not.toBe(r2.shortCode);
    });

    it('rejects invalid URL', async () => {
      await expect(createUrl('not-a-url')).rejects.toThrow();
    });

    it('creates with custom code when provided', async () => {
      const result = await createUrl('https://example.com', 'my-custom');
      expect(result.shortCode).toBe('my-custom');
    });

    it('throws 409 when custom code is already taken', async () => {
      await createUrl('https://example.com', 'taken-code');
      try {
        await createUrl('https://other.com', 'taken-code');
        expect.fail('Should have thrown');
      } catch (err) {
        expect(err.status).toBe(409);
      }
    });

    it('throws 400 for invalid custom code format', async () => {
      try {
        await createUrl('https://example.com', 'a'); // too short
        expect.fail('Should have thrown');
      } catch (err) {
        expect(err.status).toBe(400);
      }
    });
  });

  describe('getByCode', () => {
    it('returns the URL record for existing code', async () => {
      const created = await createUrl('https://example.com');
      const found = getByCode(created.shortCode);
      expect(found).toBeDefined();
      expect(found.originalUrl).toBe('https://example.com');
      expect(found.isActive).toBe(true);
    });

    it('returns null for non-existent code', () => {
      const result = getByCode('nonexist');
      expect(result).toBeNull();
    });
  });

  describe('listUrls', () => {
    it('returns empty list when no URLs exist', () => {
      const result = listUrls(1, 10);
      expect(result.urls).toHaveLength(0);
      expect(result.total).toBe(0);
    });

    it('returns paginated results', async () => {
      for (let i = 0; i < 5; i++) {
        await createUrl(`https://example.com/${i}`);
      }
      const page1 = listUrls(1, 3);
      expect(page1.urls).toHaveLength(3);
      expect(page1.total).toBe(5);

      const page2 = listUrls(2, 3);
      expect(page2.urls).toHaveLength(2);
    });

    it('clamps limit to 100 max', () => {
      const result = listUrls(1, 500);
      expect(result.limit).toBe(100);
    });
  });
});
