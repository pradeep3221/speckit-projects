import { describe, it, expect } from 'vitest';
import { validateUrl, validateCustomCode } from '../../src/middleware/validator.js';

describe('validateUrl', () => {
  it('accepts a valid http URL', () => {
    expect(validateUrl('http://example.com')).toEqual({ valid: true });
  });

  it('accepts a valid https URL', () => {
    expect(validateUrl('https://example.com/path?q=1')).toEqual({ valid: true });
  });

  it('rejects null', () => {
    const result = validateUrl(null);
    expect(result.valid).toBe(false);
    expect(result.error).toContain('required');
  });

  it('rejects an empty string', () => {
    const result = validateUrl('');
    expect(result.valid).toBe(false);
  });

  it('rejects a non-URL string', () => {
    const result = validateUrl('not-a-url');
    expect(result.valid).toBe(false);
    expect(result.error).toContain('Invalid URL');
  });

  it('rejects ftp scheme', () => {
    const result = validateUrl('ftp://example.com/file');
    expect(result.valid).toBe(false);
    expect(result.error).toContain('http and https');
  });

  it('rejects javascript scheme', () => {
    const result = validateUrl('javascript:alert(1)');
    expect(result.valid).toBe(false);
  });

  it('rejects URL exceeding max length', () => {
    const longUrl = 'https://example.com/' + 'a'.repeat(10001);
    const result = validateUrl(longUrl);
    expect(result.valid).toBe(false);
    expect(result.error).toContain('maximum length');
  });
});

describe('validateCustomCode', () => {
  it('accepts a valid alphanumeric code', () => {
    expect(validateCustomCode('my-link')).toEqual({ valid: true });
  });

  it('accepts a 3-character code', () => {
    expect(validateCustomCode('abc')).toEqual({ valid: true });
  });

  it('rejects a 2-character code (too short)', () => {
    const result = validateCustomCode('ab');
    expect(result.valid).toBe(false);
    expect(result.error).toContain('between 3 and 30');
  });

  it('rejects a 31-character code (too long)', () => {
    const result = validateCustomCode('a'.repeat(31));
    expect(result.valid).toBe(false);
  });

  it('rejects code with spaces', () => {
    const result = validateCustomCode('my link');
    expect(result.valid).toBe(false);
    expect(result.error).toContain('letters, numbers, and hyphens');
  });

  it('rejects code with special characters', () => {
    const result = validateCustomCode('my@link!');
    expect(result.valid).toBe(false);
  });

  it('rejects null', () => {
    const result = validateCustomCode(null);
    expect(result.valid).toBe(false);
  });
});
