import { describe, it, expect } from 'vitest';
import { generateShortCode } from '../../src/utils/code-generator.js';

describe('code-generator', () => {
  it('generates a code of the configured length (6)', async () => {
    const code = await generateShortCode();
    expect(code).toHaveLength(6);
  });

  it('generates only alphanumeric characters', async () => {
    const code = await generateShortCode();
    expect(code).toMatch(/^[a-zA-Z0-9]+$/);
  });

  it('generates different codes on consecutive calls', async () => {
    const codes = new Set();
    for (let i = 0; i < 100; i++) {
      codes.add(await generateShortCode());
    }
    // With 62^7 possibilities, 100 codes should all be unique
    expect(codes.size).toBe(100);
  });

  it('retries when existsCheck returns true, then succeeds', async () => {
    let callCount = 0;
    const existsCheck = () => {
      callCount++;
      return callCount <= 2; // first 2 calls say "exists"
    };
    const code = await generateShortCode(existsCheck);
    expect(code).toHaveLength(6);
    expect(callCount).toBe(3);
  });

  it('throws after maxRetries when all codes exist', async () => {
    const existsCheck = () => true; // always collides
    await expect(generateShortCode(existsCheck, 3)).rejects.toThrow(
      'Failed to generate unique short code after maximum retries'
    );
  });
});
