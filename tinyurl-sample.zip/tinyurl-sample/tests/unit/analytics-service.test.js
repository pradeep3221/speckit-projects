import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { recordClick, getStats } from '../../src/services/analytics-service.js';
import { createUrl } from '../../src/services/url-service.js';
import { createTestDb, closeTestDb } from '../helpers/test-db.js';

describe('analytics-service', () => {
  let db;

  beforeEach(async () => {
    db = await createTestDb();
  });

  afterEach(() => {
    closeTestDb(db);
  });

  it('records a click and increments click_count', async () => {
    const url = await createUrl('https://example.com');
    recordClick(url.shortCode, 'https://twitter.com', 'TestAgent/1.0');

    const stats = getStats(url.shortCode);
    expect(stats.totalClicks).toBe(1);
    expect(stats.clicks).toHaveLength(1);
    expect(stats.clicks[0].referrer).toBe('https://twitter.com');
    expect(stats.clicks[0].userAgent).toBe('TestAgent/1.0');
  });

  it('handles null referrer and user agent', async () => {
    const url = await createUrl('https://example.com');
    recordClick(url.shortCode, null, null);

    const stats = getStats(url.shortCode);
    expect(stats.totalClicks).toBe(1);
    expect(stats.clicks[0].referrer).toBeNull();
    expect(stats.clicks[0].userAgent).toBeNull();
  });

  it('tracks multiple clicks accurately', async () => {
    const url = await createUrl('https://example.com');
    recordClick(url.shortCode, null, null);
    recordClick(url.shortCode, 'https://google.com', 'Bot/2.0');
    recordClick(url.shortCode, null, 'Chrome/120');

    const stats = getStats(url.shortCode);
    expect(stats.totalClicks).toBe(3);
    expect(stats.clicks).toHaveLength(3);
  });

  it('returns null for non-existent code', () => {
    const stats = getStats('nonexist');
    expect(stats).toBeNull();
  });

  it('returns zero clicks for new URL', async () => {
    const url = await createUrl('https://example.com');
    const stats = getStats(url.shortCode);
    expect(stats.totalClicks).toBe(0);
    expect(stats.clicks).toHaveLength(0);
  });
});
