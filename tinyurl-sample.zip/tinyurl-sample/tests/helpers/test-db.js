import initSqlJs from 'sql.js';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { setDatabase } from '../../src/db/database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const schemaPath = join(__dirname, '..', '..', 'src', 'db', 'schema.sql');
const schemaSQL = readFileSync(schemaPath, 'utf-8');

/**
 * Create a fresh in-memory test database.
 * Call in beforeEach to get an isolated DB per test.
 */
export async function createTestDb() {
  const SQL = await initSqlJs();
  const db = new SQL.Database();
  db.run(schemaSQL);
  setDatabase(db);
  return db;
}

/**
 * Close and clean up the test database.
 * Call in afterEach.
 */
export function closeTestDb(db) {
  if (db) {
    db.close();
  }
  setDatabase(null);
}
