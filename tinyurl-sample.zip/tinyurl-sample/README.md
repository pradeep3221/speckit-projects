# ProjectTinyURL

A fast, minimal URL shortening service with click analytics — production-ready.

## Features

- **Shorten URLs** — Submit a long URL, get a short code back
- **Custom codes** — Optionally choose your own branded short code
- **Instant redirects** — HTTP 301 redirects with caching
- **Click analytics** — Track clicks with timestamps, referrers, and user agents
- **Paginated listing** — Browse all created URLs
- **Rate limiting** — Protection against abuse (configurable per endpoint)
- **Security hardened** — Helmet.js, CORS, input validation, no open redirects
- **Structured logging** — JSON logs with pino, request IDs for tracing
- **Health checks** — Rich `/health` endpoint with DB, uptime, and memory info
- **Dockerized** — Multi-stage Dockerfile, non-root user, health check
- **CI/CD** — GitHub Actions for lint, test, coverage, and Docker build
- **Graceful shutdown** — Drains connections, persists DB, with timeout safety net

## Quick Start

```bash
# Install dependencies
npm install

# Copy environment template
cp .env.example .env

# Start in development (with pretty logs + file watcher)
npm run dev

# Server runs at http://localhost:3000
# Swagger docs at http://localhost:3000/api-docs
```

## Production Deployment

### Docker (recommended)

```bash
# Build
docker build -t projecttinyurl .

# Run
docker run -d \
  -p 3000:3000 \
  -e NODE_ENV=production \
  -e BASE_URL=https://short.example.com \
  -e TRUST_PROXY=true \
  -e CORS_ORIGIN=https://example.com \
  -v tinyurl-data:/app/data \
  --name tinyurl \
  projecttinyurl
```

### Node.js direct

```bash
npm ci --omit=dev
NODE_ENV=production BASE_URL=https://short.example.com node src/index.js
```

### Behind a reverse proxy (nginx example)

```nginx
upstream tinyurl {
    server 127.0.0.1:3000;
    keepalive 64;
}

server {
    listen 443 ssl http2;
    server_name short.example.com;

    location / {
        proxy_pass http://tinyurl;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Request-Id $request_id;
    }
}
```

Set `TRUST_PROXY=true` when running behind a reverse proxy.

## API Reference

### Create Short URL

```bash
# Auto-generated code
curl -X POST http://localhost:3000/api/v1/urls \
  -H "Content-Type: application/json" \
  -d '{"url": "https://example.com/very/long/path"}'

# Custom code
curl -X POST http://localhost:3000/api/v1/urls \
  -H "Content-Type: application/json" \
  -d '{"url": "https://example.com", "customCode": "my-brand"}'
```

**Response (201):**
```json
{
  "shortCode": "abc1234",
  "shortUrl": "http://localhost:3000/abc1234",
  "originalUrl": "https://example.com/very/long/path",
  "createdAt": "2026-03-22T10:00:00.000Z"
}
```

### Redirect

```bash
curl -L http://localhost:3000/abc1234
# → 301 redirect to https://example.com/very/long/path
```

### Get Click Analytics

```bash
curl http://localhost:3000/api/v1/urls/abc1234/stats
```

**Response (200):**
```json
{
  "shortCode": "abc1234",
  "originalUrl": "https://example.com/very/long/path",
  "totalClicks": 42,
  "clicks": [
    { "referrer": "https://twitter.com", "userAgent": "Chrome/120", "timestamp": "2026-03-22T10:05:00" }
  ]
}
```

### List All URLs

```bash
curl "http://localhost:3000/api/v1/urls?page=1&limit=10"
```

### Health Check

```bash
curl http://localhost:3000/health
```

## Running Tests

```bash
# Run all tests
npm test

# Run with coverage (80% threshold enforced)
npm run test:coverage

# Watch mode
npm run test:watch

# Lint
npm run lint
```

## Configuration

All settings are configurable via environment variables. See [.env.example](.env.example) for the full list.

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `3000` | Server port |
| `NODE_ENV` | `development` | Environment (`development` / `production` / `test`) |
| `DB_PATH` | `tinyurl.db` | SQLite database file path |
| `BASE_URL` | `http://localhost:3000` | Base URL for generated short links (**required** in production) |
| `SHORT_CODE_LENGTH` | `7` | Length of generated short codes |
| `LOG_LEVEL` | `debug` / `info` | Log level (auto-set to `info` in production) |
| `TRUST_PROXY` | `false` | Set `true` when behind a reverse proxy |
| `CORS_ORIGIN` | `*` | Allowed CORS origin(s) |
| `RATE_LIMIT_WINDOW_MS` | `60000` | Rate limit window in milliseconds |
| `RATE_LIMIT_MAX_CREATE` | `100` | Max URL creation requests per window |
| `RATE_LIMIT_MAX_REDIRECT` | `1000` | Max redirect requests per window |
| `SHUTDOWN_TIMEOUT_MS` | `10000` | Max time to drain connections on shutdown |

## Tech Stack

| Component | Technology |
|-----------|-----------|
| Runtime | Node.js 20+ (ES Modules) |
| Framework | Express 4.x |
| Database | SQLite (sql.js) |
| Short codes | nanoid (7-char, 62-char alphabet) |
| Logging | pino + pino-http (JSON structured logs) |
| Testing | Vitest + supertest (80% coverage threshold) |
| Linting | ESLint 9 (flat config) |
| Security | helmet + cors + express-rate-limit |
| CI/CD | GitHub Actions |
| Container | Docker (multi-stage, non-root) |

## License

MIT
